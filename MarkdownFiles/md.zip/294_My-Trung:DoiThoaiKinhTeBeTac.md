# Mỹ-Trung: Đối Thoại Kinh Tế Bế Tắc

16/07/2014



### Nguồn:

Viet Bao: https://vietbao.com/a224235/my-trung-doi-thoai-kinh-te-be-tac

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/