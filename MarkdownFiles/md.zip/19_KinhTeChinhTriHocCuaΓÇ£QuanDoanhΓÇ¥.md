# Kinh Tế Chính Trị Học Của “Quân Doanh”

19/07/2017



### Nguồn:

Viet Bao: https://vietbao.com/a270050/kinh-te-chinh-tri-hoc-cua-quan-doanh-

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/