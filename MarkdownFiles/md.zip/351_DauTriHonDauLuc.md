# Đấu Trí Hơn Đấu Lực

06/12/2013

Cuộc cờ ‘Phòng Không’ của Bắc Kinh trong thuyết đấu trí...<br/><br/>Chúng ta bình luận thế nào về việc Bắc Kinh đơn phương mở ra
"vùng nhận diện phòng không" bao trùm lên các quần đảo đang
có tranh chấp với Nhật Bản?<br/><br/>Vào đề thì xin lạc đề mà nói về kinh tế học đã. Chuyện của Bắc
Kinh xin cứ để đó.<br/><br/>Năm 1994, một nhà toán học và hai kinh tế gia cùng được giải Nobel về
Kinh tế nhờ lý luận về thuyết đấu trí hay "game theory". Đó
là nhà toán học John Nash và kinh tế gia John Harsanyi tại Hoa Kỳ cùng
kinh tế gia Reinhard Selten người Đức gốc Do Thái. Thuyết đấu trí của
họ về sau được gọi là "Mô hình Nash/Harsanyi" vì do ông Nash
viết ra khi còn là sinh viên toán và ông Harsanyi giải thích cho tinh vi
hơn về mặt tâm lý và kinh tế.<br/><br/>Xin hãy lạc thêm: Về đại lược, thuyết đấu trí giải thích cách ứng
xử của hai người căn cứ trên những tính toán lợi hại trong thế tương
hằng. Giả dụ như A mà đi nước cờ này thì phản ứng của B sẽ dẫn
tới kết quả nào và cục diện cứ thể thay đổi liên tục qua nhiều cân
nhắc của đôi bên cho tới sự ngã ngũ sau cùng là thắng hay bại.<br/><br/>Thói thường, khi lâm trận như vậy, ai cũng muốn được tối đa và bị
mất tối thiểu nhưng sau cùng thì đành nhượng bộ một phần vì gặp
rủi ro là bị mất hết. Người ta cứ nghĩ là trong cuộc đấu trí hay
đàm phán như vậy, đôi bên đều biết tiến và lùi để sau cùng nhường
nhau một phần quyền lợi hầu đạt một tỷ lệ chia chác hay nhượng bộ
quân bình là 50-50.<br/><br/>Tức là bất phân thắng bại hoặc đôi bên cùng có lợi, còn hơn là
chẳng được gì.<br/><br/>Nghịch lý được ba giải Nobel Kinh tế nêu ra là trong mọi cuộc đấu
trí, duy nhất có một kết quả chung cuộc là tỷ lệ 65-35, tức là một
phe lại được nhiều hơn. Ông Harsanyi giải thích sự ngược ngạo mà nhà
toán học John Nash đã tìm ra: là vì một phe có khả năng chịu đựng
rủi ro thấp hơn và vì sợ mà nhượng bộ nhiều hơn.<br/><br/>Về nội dung của Mô hình Nash/Harsanyi thì sự thể biến hóa vô lường
và chúng ta bước vào Đông Á qua một bát trận đồ.<br/><br/>Thứ nhất, cuộc đấu trí có nhiều đối tác chứ không chỉ có hai người,
như ả Hoa đòi vuốt mũi kép Nhựt. Vì còn có Nam Hàn, Hoa Kỳ, Đài
Loan, Bắc Hàn và cả Hiệp hội ASEAN của 10 Quốc gia Đông Nam Á, lẫn
Ấn Độ và Úc Đại Lợi, tức là có ít ra 18 nước! Thứ hai, trong tập
thể ấy, hãy tưởng tượng đến sự tính toán giữa từng cặp, ví dụ như
Hoa Kỳ với Trung Quốc, Nhật Bản với Nam Hàn căn cứ trên những quan hệ
song phương của họ. Bước thứ ba là nghĩ đến thế liên kết đa phương để
từng nước tranh thủ hay thuyết phục nhau, ví dụ như giữa bốn nước dân
chủ theo kinh tế thị trường và có hiệp ước phòng thủ hỗ tương là
Mỹ, Nhật, Hàn, và Đài Loan. Từ đó thì từng nước hay từng nhóm đối
tác có nhiều chiến lược trong tinh thần biến hoá là liên kết hay đối
lập với nhau, kể cả chiến lược hăm dọa có thể sử dụng, thí dụ như
những thiệt hại khả dĩ xảy ra nếu không đạt nổi đồng thuận.<br/><br/>Bước thứ năm, sau khi tính ra những chiến lược khác nhau mà từng nước
có thể áp dụng khi đấu trí hay đàm phán thì ta vẫn trở lại chuyện
thế và lực. Tức là từng nước phải nghĩ đến phương tiện kinh tế hay
quân sự họ có thể huy động được từ bên trong, hoặc vận dụng từ các
nước liên kết khác ở vòng ngoài. Bước thứ sáu là trong lối tính
toán về huy động và vận dụng ấy, phải nghĩ đến quyền lợi có thể
chia cho nước khác căn cứ trên sự đóng góp của họ: thế gian không có
chuyện hợp tác hay yểm trợ miễn phí. Thứ bảy và quan trọng nhất
trên một trận thế có nhiều giải pháp và chiến lược khả dụng, từng
nước phải châm thêm yếu tố rủi ro hoặc khả năng chịu đựng hiểm tai
trong cách tính toán về quyền lợi của mình. Nếu chỉ nghĩ đến giải
pháp ta cho là có lợi nhất mà không lý đến rủi ro hay thiệt hại thì
mình bị nhược điểm duy ý chí trong cuộc đấu trí.<br/><br/>Sau cùng, chuyện rất quái trong cuộc cờ bát quái, nếu có người chủ
quan mà đòi tự sát thì sao?<br/><br/>Chúng ta trở lại nước cờ của Bắc Kinh.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Thiên hà ngôn tai, trời chẳng nói gì mà quốc tế cũng không có quy
định gì về quyền thiết lập hay quản trị vùng phòng không của các
nước.<br/><br/>Nhiều quốc gia lập ra vùng phòng không, gọi là ADIZ Air Defense
Identification Zone, để theo dõi phi cơ dân sự bay vào không phận của họ
trên đất liền hay ngoài biển hầu bảo vệ an ninh lãnh thổ. Mọi phi cơ
dân sự đi vào vùng ADIZ phải xác nhận căn cước và đối thoại với cơ
quan phòng không của nước "chủ nhà". Khu vực này phải rộng
hơn không phận để bộ máy phòng không kịp thời ứng phó với mối đe
dọa khả dĩ xảy ra. Gặp trường hợp khả nghi, Không quân mới đưa chiến
đấu cơ lên trực tiếp nhận diện máy bay lạ và kịp đối phó theo phép
hỏi han, dụng lễ rồi mới dụng binh, nếu có phi cơ đòi.... tự sát!<br/><br/>Ngoài Hoa Kỳ, gần hai chục nước kể cả Việt Nam, cũng có vùng bảo
vệ như vậy. Là một quốc gia quần đảo, Nhật có vùng ADIZ từ lằn ranh
do Hoa Kỳ vạch ra sau Thế chiến II, nhằm bảo vệ không phận từ hướng
Tây. Vùng ADIZ do Nhật thiết lập năm 1969 trùng với vùng đặc quyền
kinh tế EEZ, nhưng Tháng Sáu vừa qua, Nhật mở vùng ADIZ thêm 22 cây số
về hướng Tây, và khi ấy, Đài Loan than phiền là "đáng tiếc".
Rồi thôi. Đài Loan không sợ Nhật đòi tiền mãi lộ!<br/><br/>Chi tiết lý thú là lằn ranh xa nhất của Nhật nằm cách lãnh thổ
Trung Quốc có 130 cây số. Cho nên, Bắc Kinh không phát minh ra trò này
mà chỉ phản ứng.<br/><br/>Khốn nỗi, vùng ADIZ của họ đi tới mức xa nhất về hướng Đông, trùm
lên đảo Jeju của Nam Hàn, vùng ADIZ của Đài Loan và nhất là vùng ADIZ
mới của Nhật. Việc Bắc Kinh vẽ ra lằn ranh phòng vệ lên vùng phòng
không của các lân bang mới bị cho là có thái độ khiêu khích, hoặc gây
bất ổn vì làm thay đổi hiện trạng.<br/><br/>Trở lại "Mô hình Nash/Harsanyi", ta thấy vấn đề không chỉ là
trận đấu trí giữa Bắc Kinh và Tokyo trên không phận của cụm đảo
Senkaku của Nhật mà Trung Quốc nhận là của mình và gọi là Điếu Ngư.<br/><br/>Nhưng rồi sao?<br/><br/>Trên bậc thềm không gian trước khi bay vào lãnh thổ, Thiên triều Bắc
Kinh giao hẹn với thiên hạ là từ nay ra vào thì phải xin phép. Nếu
không, máy bay vi phạm sẽ hoàn toàn chịu trách nhiệm. Các hãng hàng
không dân sự đều cân nhắc rủi ro và lấy quyết định an toàn cho khách
hàng, theo kiểu tránh voi chẳng xấu mặt nào. Sau khi ngần ấy nước
than phiền thì mọi hãng máy bay đành tuân thủ để tránh họa. Yếu tố
rủi ro trong màn đấu trí khiến Thiên triều coi như thắng một keo!<br/><br/>Nhưng nếu mối nguy không đến từ phi cơ dân sự mà từ một quốc gia thì
Thiên triều tính sao?<br/><br/>Tính gì thì tính, sau khi vạch ra luật chơi mới thì phải có khả năng
động thủ nếu quả thật là bị đối thủ khiêu khích. Khả năng đó gồm
có hai mặt. Một là phải theo dõi được mọi chuyện trên không phận
trùng lập với lằn phòng thủ của xứ khác. Thứ hai là phải thi hành
được lời răn đe.<br/><br/>Khả năng theo dõi đó đòi hỏi sự phối hợp giữa lục quân, hải quân
với không quân và "Đệ nhị Pháo binh" (hệ thống hỏa tiễn).
Bắc Kinh chưa có khả năng phối hợp này nếu so với đối thủ thật, là
Nhật Bản. Nước Nhật là quần đảo có cơ sở quân sự nằm sát Hoa lục,
với trình độ kỹ thuật cao hơn. Hệ thống bảo vệ trên đất liền của
Trung Quốc lại ở quá xa "hiện trường" là lằn ranh ADIZ nằm
mãi ngoài khơi.<br/><br/>Thứ hai, khi hữu sự thì phải có khả năng ra đòn và đỡ đòn khi bị
phản đòn. Cụ thể là muốn thật sự bảo vệ không phận thì còn phải
xác định đối tượng, chứ không thể bắn hạ hay hăm dọa bắn hạ những
vật lạ mình chưa biết là gì và bắn hạ bằng võ khí nào là thích
ứng. Yêu cầu ấy đòi hỏi loại chiến đấu cơ có thể ngăn chặn và tiêu
diệt đối thủ theo đúng lời hăm, và các chiến đấu cơ phải có căn cứ
ở gần hiện trường.<br/><br/>Vì nhoài mình quá xa ra ngoài, Bắc Kinh cũng chưa có khả năng đó.<br/><br/>Cho nên, Thiên triều mới chỉ dọa già trong khi ráo riết thi đua để
tiến tới trình độ ta gọi là "lực tòng tâm". Nhưng kết quả
thì thần dân hỷ hả khi thấy lãnh đạo đơn phương vẽ lằn ranh lên trời
mà người đời đều sợ. Thế gian này thiếu gì người đã tránh voi và
không giây với hủi!<br/><br/>Nhưng kết luận như vậy vẫn chưa là đấu trí thật trên trận đồ bát
quái!<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Nhật từng là đại cường hải dương khi Thiên triều còn ăn mắm mút
giòi, mắt đăm đăm nhìn vào trong núi và bị đánh cho tơi tả. Không có
Mỹ đế nhập cuộc và dứt điểm bằng hai quả bom nguyên tử vào năm 1945
thì chưa chắc Mao Trạch Đông đã lên ngôi Hoàng đế. Cũng từ cục diện
đó mà Nhật bị giải giới, trong mọi chuyện thì chỉ có thế thủ chứ
không được phép công.<br/><br/>Là quốc gia quần đảo, ngày nay Nhật chỉ có một đất lùi là lùi ra
biển. Trên đầu thì đến Bắc Hàn còn có thể tung hứng hỏa tiễn làm
vui, dưới nước thì Thiên triều Bắc Kinh lại vẽ ra lằn ranh mới. Trên
lãnh thổ bát ngát của mình, khi gặp rủi ro, lãnh đạo Trung Quốc còn
có đất lùi là khu vực nội địa. Nhật Bản thì không.<br/><br/>Vì vậy, trong khi Hoa Kỳ dẫn rượu và ăn nói nước đôi với nhiều bửu
bối yểm sẵn ngoài khơi, và Trung Quốc tưởng bở mà lấn đất giành
hơi, Nhật Bản nghĩ tới kịch bản tệ nhất của trận đấu trí. Không ồn
ào múa may như anh Sơn Đông mãi võ ngoài chợ đời, họ tự chuẩn bị cho
trận đấu lực. Trên cuộc cờ rắc rối ấy, giữa cái danh giả của một
Trung Quốc hung hăng mà đầy mặc cảm và nỗi lo thật của Nhật Bản,
yếu tố nào mới thật sự đáng sợ?<br/><br/>Và khi có chuyện, các lân bang và thế giới sẽ phản ứng thế nào?
Bênh vực Trung Quốc? Ảo!

### Nguồn:

Viet Bao: https://vietbao.com/a214256/dau-tri-hon-dau-luc

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/