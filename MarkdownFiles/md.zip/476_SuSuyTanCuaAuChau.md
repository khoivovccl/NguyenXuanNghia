# Sự Suy Tàn Của Âu Châu

16/11/2011

<p>Sự
Suy Tàn Của Âu Châu</p><p>Nguyễn
Xuân Nghĩa</p><p></p><p>..nhiều
phần thì Âu châu sẽ suy tàn và phân rã, để sẽ bị thiên hạ chi phối sau hơn 500
năm khống chế thiên hạ...</p><p>Hai
chục năm sau sự sụp đổ của Liên Xô, Liên Âu cũng đến lúc tàn"</p><p>Từ
22 tháng nay, thế giới bàng hoàng theo dõi cuộc khủng hoảng của Liên hiệp Âu
châu. Riêng trong Tháng 11 chưa kết thúc, sau Hy Lạp đến nước Ý cũng trôi vào
chấn động chính trị làm các thị trường tài chánh quốc tế đều tơi tả. Nhưng viễn
ảnh Âu Châu có thể còn kinh hoàng hơn sự sụp đổ của hệ thống ngân hàng hoặc nạn
phân rã của đồng Euro: một sự đổi thay của trật tự thế giới! </p><p>Kỷ
nguyên gọi là "Hiện đại" của chúng ta khởi sự từ năm 1492, với cuộc
thám hiểm và việc phám phá ra "Tân Thế giới" của Columbus. Kể từ đó,
Âu châu thống trị toàn cầu và đặt ra luật chơi cho cả nhân loại. Kỷ nguyên đó tồn
tại được đúng 500 năm, vì kết thúc vào năm 1991, là khi một cường quốc truyền
thống của Âu châu là Liên bang Xô viết tan rã. Hai chục năm sau, là giờ này đây,
Liên hiệp Âu châu cũng đi tới mé vực đó. Và có thể sẽ chung số phận.</p><p>Nước
Nga vẫn tồn tại, là một cường quốc có ảnh hưởng. Các nước Âu châu cũng thế. Nhưng
dự án Liên Âu sẽ cáo chung. Sau đó là gì thì chưa ai biết - mà ai cũng nên sợ!</p><p>Nhìn
cách khác: vì ở sát nách - bị kẹp sát nách - ta hay nói về chuyện "hợp
tan" truyền thống của Trung Hoa mà ít chú ý đến lẽ hợp tan của một lục địa
đã chinh phục toàn cầu và khuất phục nhiều dân tộc hay quốc gia khác trên thế
giới. Âu châu đang đi vào tiến trình "hợp rồi tan" mà vụ khủng hoảng
tài chánh chỉ là biểu hiện ngoài da.</p><p>***</p><p>Do
địa dư hình thể phân tán và đầy khác biệt - chứ không vuông vức và đầy lợi thế
trời cho như lãnh thổ Hoa Kỳ - Âu châu là một tập thể phức hợp của nhiều cộng đồng
dân tộc đã tiến dần đến hình thái "quốc gia". </p><p>Nhưng
mỗi bước tiến lại là một trường chinh chiến, có khi kéo dài trăm năm. Trong lịch
sử cận đại, đó là ba trận đại chiến, năm 1871 khi nước Đức thống nhất, năm 1914
là Thế chiến I và năm 1939 là Thế chiến II. Kể từ đó, từ 1945 trở về sau, Âu
châu đã có hòa bình và các nước chịu sống chung với nhau, thậm chí còn lập ra một
đồng tiền dùng chung giữa 17 nước là đồng Euro. Nói như Francis Fukuyama,
"Lịch sử cáo chung"" Hay "Xã tắc Vững bền""</p><p>Sự
thật lại không được như vậy và cả thế giới, trước tiên là Âu châu, đã hiểu lầm!</p><p>Trước
tiên là hiểu lầm về... Hoa Kỳ. </p><p>Nước
Mỹ không muốn dính vào thiên hạ sự của Âu châu, đã tham chiến rất chậm trong cả
hai trận Thế chiến và sau đó mưu tìm hòa bình cho đại lục địa Âu Á qua chính
sách "quân bình bất ổn". Chữ "chia để trị" thì dễ hiểu hơn
mà cũng dễ bị hiểu sai vì khái niệm "trị", không phải là cai trị mà
là trừ khử mầm loạn - chủ nghĩa quốc gia cực đoan của Âu châu - bằng cách khác.</p><p>Sau
Thế chiến II, Hoa Kỳ chia đôi cường quốc đã ba lần gây đại chiến tại Âu châu,
là nước Đức, trong một Âu châu cũng bị chia đôi giữa hai ngả Đông-Tây (Cộng sản
và Dân chủ) bên cạnh một khối Cộng sản lại có hai đầu là Nga và Tầu đều tranh
nhau bắt bí để giao kết với Mỹ. </p><p>Hoa
Kỳ gìn giữ trật tự bất ổn đó bằng sự hiện diện quân sự, nuôi dưỡng nền kinh tế
bị tàn phá bằng viện trợ và phát triển bằng quy luật thị trường. Tình trạng đó
kéo dài suốt thời Chiến tranh lạnh, cho đến khi nước Đức tái thống nhất năm
1989, Liên Xô tan rã năm 1991 thì Hoa Kỳ ngó qua chuyện khác. </p><p>Việc
bảo vệ Âu châu - hay chiếm đóng nước Đức tùy cách gọi - hết là ưu tiên về quân
sự.</p><p>Sau
đấy, cả Hoa Kỳ lẫn thế giới, nhất là Âu châu, đã lại có một sự hiểu lầm khác. </p><p>Nước
Mỹ lạc quan tin rằng "lịch sử cáo chung" với sự sụp đổ của đối thủ và
bắt đầu an hưởng "cổ tức hoà bình" thời Bill Clinton, mà không thấy
ra là hòa bình chưa có, vùng Balkans gặp loạn và cuộc chiến với lực lượng Hồi
giáo quá khích đã manh nha. Trong 10 năm đầu, từ 1991 đến vụ khủng bố 2001, Hoa
Kỳ ngao du trong hoang tưởng vì trở thành độc bá. Đó là "Hội chứng Tiêu
Bán Sơn" trong truyện võ hiệp Kim Dung, sự trống vắng tâm lý khi kẻ thù
truyền kiếp đã tự diệt.</p><p>Nhưng
sự hiểu lầm của Âu châu lại còn thê thảm hơn.</p><p>***</p><p>Không
biết rằng - mà dù một số lãnh đạo có biết thì cũng chẳng nói ra - hoà bình Âu
châu là trạng thái bất ổn được Hoa Kỳ bảo vệ, khi Chiến tranh lạnh kết thúc,
các nước Âu châu đều vui mừng là mình được "giải phóng". </p><p>Bờ
Tây thì Mỹ rút, bờ Đông thì Nga gục. Cả bốn hướng Nam Bắc Đông Tây đều rạo rực
bước vào tiến trình thống nhất với Thỏa ước Maastritch và sự hình thành của
Liên Âu năm 1993. Nhiều nhà lãnh đạo Âu châu, nhất là Pháp, còn mơ ước xây dựng
một thế giới đa cực làm lực đốitrọng với
nước Mỹ độc bá. </p><p>Mà
đấy là chuyện nhỏ! </p><p>Chuyện
lớn hơn vậy về sự hồ hởi là khi một số quốc gia Âu châu muốn tiến xa hơn qua thống
nhất tiền tệ và sự ra đời của đồng Euro năm 1999. Y như dự án Liên Âu, đồng
Euro sẽ là lực đối trọng với Mỹ kim, trở thành ngoại tệ dự trữ có thế giá của
thế giới khả dĩ cạnh tranh với đồng bạc xanh.</p><p>Tổng
hợp lại về thế là Liên Âu và về lực là đồng Euro, các nước Âu châu mơ ước sự
hình thành của Liên bang Âu Châu, United States of Europe, như Liên bang Hoa Kỳ,
United States of America. </p><p>Từ
nay, bên này Đại tây dương sẽ có một thế lực mới, cũng lại như xưa là giữ vị
trí cân bằng giữa Hoa Kỳ và Liên bang Xô viết. Nhưng dũng mãnh hơn xưa vì có
dân số hơn 500 triệu và sản lượng 16.200 tỷ, lớn hơn sức mạnh kinh tế chừng 15
ngàn tỷ của Mỹ. Mà khỏi phải lo lắng gì về ngân sách quốc phòng, vì đã có Minh ước
NATO cáng đáng, với tay chủ chi ngờ nghệch là Chú Sam. Đấy là một sự hiểu lầm của
Âu châu, không về nước Mỹ mà về chính mình. </p><p>Chúng
ta lạnh lùng trở lại chuyện bạc tiền, chỉ vì có thực mới vực được đạo.</p><p>***</p><p>Trên
tổng thể, Âu châu quả là đông dân và có sản lượng giàu hơn của Mỹ. Âu châu còn
có tiếng nói quốc tế khác, với khảo hướng - approach - ôn tồn và ngoại giao hơn
nước Mỹ thiếu văn hoá. Đó là "quyền lực mềm" - soft power - của các nước
có lịch sử và dày kinh nghiệm về thiên hạ sự từ khi Hoa Kỳ chưa ra đời. Nhờ vậy,
Âu châu không bị thế giới Á Rập thù ghét như nước Mỹ và rất được lòng dân Á Rập
tại Palestine hay nhiều nơi khác. Âu châu lại còn một thị trường tiêu thụ và nhập
cảng hàng hóa mạnh nhất từ một thế lực đang lên là Trung Quốc.</p><p>Khách
quan thì Âu châu có dư thế lực góp tiếng nói và cả hành động cho cộng đồng thế
giới. </p><p>Nhưng
tất cả kiến trúc vĩ đại ấy nằm trên hai sự thật rất dễ mất lòng. </p><p></p><p>Thứ
nhất, sau mấy trăm năm nội chiến liên tục, nếu Âu châu có được hòa bình để sống
chung với nhau trong thời Chiến tranh lạnh cũng là do sự can thiệp hay bảo vệ của
Mỹ. Nhu cầu bảo vệ ấy không còn và nước Mỹ theo đuổi ưu tiên khác. Thứ hai, nếu
Âu châu có dự tưởng lớn lao như vậy về thiên hạ sự thì vẫn chưa có cơ chế chính
trị thích hợp: lãnh đạo Liên Âu ở trên là bộ máy thư lại vô thẩm quyền trước đòi
hỏi chính đáng mà đầy mâu thuẫn của từng thành viên, của từng quốc gia. Chủ
nghĩa quốc gia chưa cáo chung bên dưới lớp men thống nhất của Âu châu.</p><p>Vụ
khủng hoảng tài chánh hiện nay xuất phát từ sự thật thứ hai này.</p><p>Mọi
sự khởi đầu vào năm 2008 khi Hoa Kỳ bị khủng hoảng tài chánh. Khi ấy, Âu châu
chưa nhìn ra nhược điểm nội tại mà cứ tưởng và còn làm cho thế giới lầm tưởng rằng
tất cả xảy ra tại vì sự bất cẩn hay bất lương của các doanh nghiệp tài chánh Mỹ,
hoặc sự bất toàn của tư bản chủ nghĩa.</p><p>Về
an ninh, đáng lẽ người ta đã phải thấy ra sự rạn nứt và sụp đổ tất nhiên của
"kiến trúc Âu châu" khi Liên bang Nga tấn công Georgia Tháng Tám năm
2008. Vì khi ấy, Đức và Pháp không có phản ứng bảo vệ các nước Đông Âu và Trung
Âu vừa gia nhập mà lại mau mắn hòa giải với Tổng thống Vladimir Putin của Nga.
Lý do hoà giải là quyền lợi kinh tế quốc gia. Là khí đốt hay cơ hội đầu tư... Sự
thống nhất về chính trị của Liên Âu như một thế lực quốc tế chỉ là ảo giác.</p><p>Thứ
nữa, sự thống nhất về kinh tế cũng vậy. </p><p>Đáng
lẽ người ta đã phải thấy ra sức xâm nhập và giao kết rất sâu của hệ thống ngân
hàng Âu châu, dưới sự chỉ đạo của từng quốc gia Âu châu. Các ngân hàng đã đầu tư
và cho vay tới ngập đầu để thi hành chánh sách kinh tế quốc gia. Khi gặp khủng
hoảng rồi bị nguy cơ vỡ nợ vì mất vốn thì cơ chế lãnh đạo Âu châu không có khả
năng giải quyết, một cách linh động, chủ động và mau lẹ. Khủng hoảng lan rộng
còn phơi bày ra một thực tế khác là nhiều quốc gia đã tận dụng lợi thế thống nhất
để mưu tìm quyền lợi riêng, cũng vì chủ nghĩa quốc gia. Đến khi hữu sự thì
không muốn và không có khả năng đắp vốn để chuộc nợ. Ở giữa, đồng Euro là đồng
sứt!</p><p>Khủng
hoảng tài chánh và ngân hàng, khủng hoảng quốc trái - sovereign debt - và khủng
hoảng Euro là ba cái mặt của một hình tháp, mà cốt lõi bên trong là một tình trạng
vô quyền vì Âu châu không có cơ chế cưỡng hành dự án phiêu hốt của mình.</p><p>Kiến
trúc Âu châu là một khối tự do mậu dịch thống nhất, nhưng quyết định về ngân
sách hay thuế khóa từng nước vẫn thuộc chính quyền của từng quốc gia mà các cơ
chế thống nhất không thể điều động hay kiểm soát. Hội đồng hay Uỷ ban Âu châu
và các công chức quốc tế tại thủ phủ Âu châu là Bruxelles của Bỉ, hoặc Ngân
hàng Trung ương Âu châu tại Frankfurt của Đức, là những cơ chế không có thẩm
quyền khi suy trầm kinh tế hay giông bão thị trường nổi lên. </p><p>Y
như về đối ngoại - Âu châu không có sức mạnh quân sự bảo vệ tiếng nói nên mới
phải dùng quyền lực mềm - về đối nội, Âu châu không có sức mạnh pháp chế để bảo
vệ kỷ cương của chi tiêu.</p><p>Thí
dụ nổi bật là cách suy nghĩ của hai nước trong cuộc, Hy Lạp và Đức.</p><p>Hy
Lạp có thể khôn ngoan hay gian manh vay mượn để tiêu xài quá khả năng vì từng
là nạn nhân của nội chiến và Chiến tranh lạnh nên nghĩ rằng mình phải được các
nước đền bù. Vì vậy họ mới man khai sổ sách để gia nhập khối Euro và thoải mái
xài đồng tiền chung, vì nếu có gì thì đã có kinh tế Đức hay các xứ khác cáng đáng.
</p><p>Sống
nhờ xuất cảng, kinh tế Đức cũng thoải mái đầu tư và hào phóng cho vay để xứ
khác tiếp tục mua hàng Đức. Hãy nghĩ đến một nhà nước như nhà băng, cứ khôn
ngoan cho thân chủ vay tiền để mua nhà mua xe do chính mình sản xuất ra.... Khi
hữu sự là ngày nay, dân Hy Lạp cho rằng mình là nạn nhân của những đòi hỏi quá đáng
của Đức. Còn dân Đức thì mất kiên nhẫn vì cứ phải đóng thuế cho dân Hy Lạp được
về hưu sớm, với đầy đủ bổng lộc.</p><p>Dưới
cái dù lủng lỗ của tập thể, xứ nào cũng nghĩ đến quyền lợi tối thượng của Tổ quốc,
của dân tộc, quốc gia. Và tin vào khả năng can thiệp của chính quyền hơn là phản
ứng của thị trường. Vụ khủng hoảng 2008 đã quạt vào ảo giác Âu châu: sự bất lực
của chính quyền và hốt hoảng của thị trường.</p><p>***</p><p>Người
dân Âu châu đang gặp sự chọn lựa sinh tử: bảo vệ thành quả của hơn nửa thế kỷ hội
nhập trong hoà bình hay bảo vệ quyền lợi kinh tế xã hội của từng quốc gia" Nếu
muốn hội nhập thì phải tiến tới thể chế liên bang và mặc nhiên thủ tiêu chính
quyền của mình, để chấp nhận quy chế của một "tiểu bang" Âu châu. Nhiều
người không muốn vậy và đã từng làm kiến trúc Âu châu rúng động khi từ chối Hiến
pháp mới của Âu châu qua các cuộc trưng cầu dân ý từ năm 2005. </p><p>Một
số quốc gia, cả chục nước, nhất là tại miền Bắc, còn từ chối thủ tiêu đồng bạc
quốc gia để dùng chung đồng Euro. Lập trường hoài nghi của Anh là một thí dụ
tiêu biểu. Kỷ cương về chi thu ngân sách và nghiệp vụ ngân hàng của các nước Bắc-Âu
là thí dụ khác.</p><p>Nhìn
qua lãnh vực an ninh, người ta cũng thấy dị biệt về quan điểm về phương hướng
phòng thủ của lá chắn chiến lược. </p><p>Các
nước miền Bắc vẫn đề cao mục tiêu phòng vệ Bắc Đại Tây dương của Minh ước NATO
qua sự hợp tác chặt chẽ với Hoa Kỳ. Các nước miền Nam thì muốn NATO nhìn xuống
khu vực Trung Đông vì mối nguy xuất phát từ đó. Các nước Đông Âu và Trung Âu lại
không quên được mối nguy truyền thống từ nước Nga, hoặc một sự liên kết loạn
luân giữa hai cường quốc Nga và Đức ở hai hướng Đông và Tây.</p><p>Vì
vậy, Âu châu đang bị sức ly tâm rất mạnh từ trong ruột gan và trật tự bất ổn từ
sau Thế chiến II đang chuyển dịch, hoặc sụp đổ. </p><p>Một
trật tự mới sẽ chỉ thành hình khi Hoa Kỳ chấp nhận là cường quốc "vạn năng
mà không toàn năng", có ảnh hưởng tỏa rộng mà không thể chi phối được
thiên hạ sự của toàn cầu. Cuộc chiến chống khủng bố Hồi giáo là cơ hội thức tỉnh
cho lãnh đạo nước Mỹ. Thứ hai, Liên bang Nga đã tái xuất hiện như cường quốc có
ảnh hưởng trên khu vực quỹ đạo truyền thống, vùng biên ngoại, như Georgia và
Ukraine, sẽ can dự mạnh hơn vào Âu châu, hợp tác chặt chẽ hơn với nước Đức để
tìm nguồn tiếp vận kỹ thuật cho hệ thống sản xuất lạc hậu của mình. Điều này đã
xảy ra. </p><p>Yếu
tố thứ ba là tham vọng của Trung Quốc với sự lớn mạnh của kinh tế và quân sự nhằm
bảo vệ quyền lợi toả rộng hơn xưa của mình. Tại Đông Á, người ta đang chứng kiến
hiện tượng này.</p><p>Yếu
tố sau cùng thuộc về Âu châu: các cường quốc trong tập thể muốn gì và có khả năng
thực hiện ra sao khi Hoa Kỳ đã giảm dần ảnh hưởng và không còn giữ chức năng
gián chỉ - can gián - những phản ứng quốc gia cực đoan đã từng thấy tại Âu
châu"</p><p>Trong
khi chờ đợi sự thành hình của "trật tự mới" ở bốn khía cạnh đó (Hoa Kỳ,
Liên bang Nga, Trung Quốc và Âu châu), các nước Âu châu phải chọn lựa. Nếu đồng
Euro tan rã thì Âu châu sụp đổ, Tổng thống Pháp đã nhiều lần cảnh báo như vậy.
Nhưng nếu đồng Euro có hồi phục và tìm lại ảnh hưởng dự tưởng của nó, chưa chắc
Liên hiệp Âu châu đã có thể tồn tại theo khuôn khổ hiện nay. Nước Đức phải can
thiệp và chi phối chính sách kinh tế tài chánh của từng nước, nghĩa là đạt mục
tiêu cố hữu của quốc gia dân tộc, y như Đức quốc xã, nhưng bằng cách khác. </p><p>Khi
đó, Anh quốc hay Ba Lan và nhiều nước khác có chấp nhận không"...</p><p>Khó
ai biết trước được tương lai. Nhiều phần thì phản ứng quốc gia cực đoan sẽ trỗi
dậy, hiện tượng đã thấy từ vụ Tổng khủng hoảng 1929-1933 - với minh diễn bi đát
là phong trào phát xít và Thế chiến II. Nhẹ hơn thế là phản ứng hoài nghi sự thống
nhất Âu châu. Các chính đảng chủ trương chống lại sự thống nhất sẽ thắng cử,
khiến giải pháp chung cho vụ khủng hoảng hiện nay càng thêm khó khăn.</p><p>Vì
vậy, nhiều phần thì Âu châu sẽ suy tàn và phân rã, để sẽ bị thiên hạ chi phối
sau hơn 500 năm khống chế thiên hạ. Chỉ mong rằng không vì đó mà chiến tranh
liên-Âu sẽ lại tái phát.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a179808/su-suy-tan-cua-au-chau

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/