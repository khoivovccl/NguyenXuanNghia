# Kinh Tế Việt Nam Có và Không Có Nguyễn Tấn Dũng

27/01/2016



### Nguồn:

Viet Bao: https://vietbao.com/a248570/kinh-te-viet-nam-co-va-khong-co-nguyen-tan-dung

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/