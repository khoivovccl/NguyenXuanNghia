# Biến Động Tài Chánh Trung Quốc

14/01/2016



### Nguồn:

Viet Bao: https://vietbao.com/a248030/bien-dong-tai-chanh-trung-quoc

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/