# Trái Phiếu Trung Quốc Bị Rách

21/04/2016



### Nguồn:

Viet Bao: https://vietbao.com/a251970/trai-phieu-trung-quoc-bi-rach

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/