# Hài Kịch Họp Với Iran Về Võ Khí Hạch Tâm

16/04/2015



### Nguồn:

Viet Bao: https://vietbao.com/a236468/hai-kich-hop-voi-iran-ve-vo-khi-hach-tam

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/