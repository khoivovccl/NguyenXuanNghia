# Nắn Giò Bát Tiên

31/01/2014

Đầu năm giải phẫu ngược một truyền thuyết vui...<br/><br/>Trong một số Tết thì bình luận những gì mà vẫn ra vẻ "ôn cố tri tân"
và nói gì về truyền thống mà vẫn cứ là giải ảo về thời sự trong tinh thần mua
vui cũng được một vài bát thang?<br/><br/>Xin nói về sự tích "bát tiên" mà mọi người Việt nghĩ rằng mình có văn
hóa đều biết.<br/><br/>Đấy là tám nhân vật bất tử theo tín ngưỡng Lão giáo của văn hóa Trung Hoa, có
thể là tổ tiên của những ông Công ông Táo mà bà con ta vẫn o bế trong ngày Tết...<br/><br/>Họ có thể là nhân vật lịch sử. Tức là dù mơ hồ thì cũng có thật, như trường hợp
Lã Động Tân, Hán Chung Li và Trương Quả Lão. Hay hoàn toàn hư cấu như năm người
kia. Họ có thể là quan to như Tào Quốc Cữu, tướng giỏi như Hán Chung Li, thuật
sĩ giang hồ như Trương Quả Lão hay văn nhân tú sĩ như Lã Động Tân hoặc ngát tiếng
cầm ca như Hàn Tương Tử. Họ có thể là mỹ nhân diễm tuyệt như Hà Tiên Cô hay là
tay anh chị - vừa anh vừa chị vì... ái nam ái nữ tùy cái hứng vẻ vời của đời
sau - như cô/cậu Lam Thái Hoà. Lam Thái Hòa quả là nhân vật hiện đại!<br/><br/>Nhân vật kiệt xuất và "ấn tượng" nhất – xin mượn chữ ấn tượng vô
nghĩa của người Hà Nội – chính là Lý Thiết Quải.<br/><br/>Trong tám người, đấy là người đầu tiên đã tu lên hàng trường sinh bất tử vì là
môn đồ chân truyền của vị thủy tổ ở tận đầu nguồn, là Lão Tử.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Luận về văn học sử Trung Hoa thì truyền thuyết về một số nhân vật phi phàm đã
lác đác xuất hiện từ thời Hán Đường, ứng vào thời Bắc thuộc của nước Nam. Rồi
cô đọng dần và hệ thống hóa vào đời Tống, khi nước Nam ta giành lại nền độc lập.
Bát tiên chỉ bắt đầu hiển lộ từ thời Kim vào đầu thế kỷ 12, rồi nói có sách
mách có chứng về tích "quá hải" là từ thời Nguyên Mông - khi Hán tộc
rơi vào ách cai trị Mông Cổ từ thế kỷ 13.... Qua đời Minh về sau thì hình ảnh
bát tiên đã tràn ngập sân khấu và nghệ thuật rồi xuất hiện ở từng nhà. Kể cả
nhà Nam của chúng ta.<br/><br/>Luận về văn hóa chính trị, hình ảnh rạng rỡ nhất của bát tiên khởi sự xuất hiện
vào đời Tống.<br/><br/>Đời Tống cũng là khi văn hóa Trung Hoa tỏa sáng với rất nhiều phát minh kỹ thuật
và khi cuộc sống người dân lại có vẻ dễ thở nhất nhờ sự suy yếu của triều đình
trung ương. Yếu nhất trong cả ngàn năm lịch sử gần đây của Trung Quốc. Mà yếu
quá thì gẫy! Kể từ đó Trung Quốc mới bị các dị tộc họ coi là man rợ ở chung
quanh khuất phục, sau Liêu, Kim, Tây Hạ, Tây Tạng thì có Mông Cổ và Mãn Thanh
cho đến năm 1911...<br/><br/>Khi nhớ lại xuất xứ bát tiên và Bồng Lai cảnh thì ta cũng nghĩ đến một tiền lệ
là Trúc Lâm Thất hiền vào đời Tấn (năm 263) của con cháu Tư Mã Ý sau thời Tam
Quốc.<br/><br/>Đời Tấn là khi ách độc tài lên tới đỉnh hắc ám nhất và một số trí thức bèn trốn
vào rừng trúc. Thất hiền là tiêu biểu cho nền văn hóa ở ẩn mà thật ra là lánh nạn
khi triều đình Khổng Nho được tái lập. Thế rồi trước sau, họ đều phải bỏ áo Lão
khoác áo Khổng ra hợp tác với chính quyền cách mạng. Chỉ còn Kê Khang là chết
thảm, một phần cũng vì tay các đồng chí đồng đạo cũ trong vườn Trúc Lâm. Đừng vội
chê những kẻ như Sơn Đào, họ hòa giải hòa hợp với chế độ tham tàn để góp phần
xây dựng đất nước!<br/><br/>Một ngàn năm sau, khi đất nước Trung Hoa đã mất chủ quyền sau đời Tống thì bậc
đại trí nghĩ xa hơn vườn trúc mà dựng nên đảo Bồng Lai và cõi bất tử, với tám
người đã thành tiên. Trong số này, người bất tử đầu tiên và đúng là số một,
không phải là Lã Động Tân mà là Lý Thiết Quải.<br/><br/>Nôm na là Lý Nạng Sắt...<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Mỗi thời lại có một truyền thuyết về nhân vật này, nhưng tựu trung về bi kịch
thì chỉ vì một tên đệ tử... có hiếu.<br/><br/>Chẳng biết là sinh vào đời Chu hay thời Tiên Tần, hoặc đời Tống, nhân vật Lý
Huyền hay Lý Ngưng Dương, Lý Hồng Thủy, Lý Nguyên Trung, có tên lúc nhỏ khá tiền
định là Quải Nhi và có tự là Lý Khổng Mục. Chỉ biết rằng ông học đạo với chính
Lão Đam, hay hóa thân của vị sư tổ này là Thái Thượng Lão Quân, và lên tới bậc
phi phàm. Ông coi chuyện hình tướng là vô dụng, tiền tài là dép rách. Hơi có
mùi thiên đường xã hội chủ nghĩa...<br/><br/>Một ngày kia, Lý Huyền xuất hồn lên trời gặp thầy và dặn đệ tử là canh cái xác
phàm của mình trong một tuần bảy ngày thì sẽ về. Đến ngày thứ sáu thì tên đệ tử
nóng ruột vì có bà mẹ vừa mất. Chữ hiếu là quan trọng nhất. Quay về cư tang là
chuyện phải đạo. Nhưng sợ cái xác phàm của thầy bị phạm nên trước khi đi lại đốt
cháy thành than.<br/><br/>Cho nên khi hồn vía Lý Huyền trở về thì mất hộ khẩu.<br/><br/>Lang thang mãi nên đành gia nhập hàng ngũ quần chúng nhân dân lao động, là mượn
cái xác của một người hành khất vừa chết. Quyết định sáng suốt mà thê thảm.<br/><br/>Người ăn mày chỉ có một chân, cái đầu gớm ghiếc, bộ mặt ghê hồn và tóc tai bù
xù dơ bẩn. Ổ trên kia, t Thầy Lão Tử thương người đệ tử không may mà phóng xuống
một vòng vàng để cuốn tóc cho gọn, và một cái nạng bằng sắt để di chuyển cho
nhanh. Từ đó Lý Huyền mới có dáng dị nhân và cái tên là Lý Nạng Sắt...<br/><br/>Việc đầu tiên của Lý Thiết Quải là thi triển thần thông. Trút thuốc trong bầu hồ
lô cứu sống bà mẹ của tên đệ tử hiếu đễ mà lơ đãng này, rồi đi hành hiệp khắp bốn
phương để cứu giúp người nghèo khổ, những kẻ bị áp bức.<br/><br/>Ông xứng đáng là khuôn mặt của Trung Quốc... thời cách mạng.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Ngày nay, nếu ai có sợ dáng vẻ dị hợm của Trung Quốc thì đã có người nói đến từ
tâm của Lý Thiết Quải. Truyền thuyết phổ biến là họ Lý này hơi nóng nẩy thô bạo
nhưng thật ra thì Trung Quốc cũng biết thương người. Với hình tượng của kẻ bần
cùng nhất, đến độ phải đi ăn mày, Trung Quốc vẫn kết một cái kiềng vàng rực rỡ
trên đầu. Có nghĩ đến cái vòng kim cô trên đầu kẻ sĩ làm quan hay đảng viên cao
cấp thì cũng chẳng sai.<br/><br/>Và dù có cụt chân thì khi nổi giận nạng sắt đã thừa sức phang tới Đông hải...<br/><br/>Phép phân tâm học đời nay có thể nhìn ra nhiều ý nghĩa tiềm ẩn như vậy trong một
nếp văn hóa tập thể. Sau mấy trăm năm lầm than nơi Bồng Lai không hề có, Trung
Quốc ngày đang mơ ngày hái quả. Họ gọi đó là quá hải....<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Chuyện cận đại "bát tiên quá hải" -và hai lần đụng quân Nhật- có được
kể rõ trong báo xuân Việt Báo năm nay. Nhân đây, người viết thay mặt các tác giả
góp phần cho báo xuân, xin có lời cám ơn chung tới quí vị bạn đọc. Báo xuân Việt
Báo Tết Giáp Ngọ, với chủ đề "60 Năm Di Cư Di Tản - Gốc Việt và Nước Mỹ Di
Dân- Thế Hệ Thiên Niên Kỷ", 320 trang, bán lẻ 9 Mỹ kim, dù không kèm bất cứ
quà tặng nào, vẫn được bạn đọc khắp nơi nồng nhiệt hưởng ứng. Cho tới cuối tuần
qua, số lượng báo xuân dành cho các đại lý, tiệm sách hiện đã bán ra hết và
không thể tiếp tục cung cấp thêm. Trân trọng cáo lỗi. Báo xuân Việt Báo hiện chỉ
còn số lượng giới hạn tại toà báo dành cho chợ Tết khai mạc cuối tuần này. Hẹn
gặp quí vị trong chợ Tết.<br/><br/>Kính chúc Năm Giáp Ngọ Thái Hoà.<br/><br/>Nguyễn Xuân Nghĩa

### Nguồn:

Viet Bao: https://vietbao.com/a216633/nan-gio-bat-tien

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/