# Bị Văng Miểng Vào... Mắt Kiếng

18/10/2013

Một trong những tổn thất của trận đấu về ngân sách là viễn kiến
của nước Mỹ...<br/><br/>Sau khi Thượng rồi Hạ viện Hoa Kỳ nhồi banh đến ngày cuối, vào phút
chót thì đôi bên cùng đá trái banh ngân sách ra biên, cho tới đầu năm
sau: Chính quyền liên bang có ngân sách tới giữa Tháng Giêng và định
mức đi vay được nâng cho tới mùng bảy Tháng Hai. Tức là sau Giáng
Sinh, hai phe sẽ lại cù cưa đá tiếp. Cho đến cú đá phạt, penalty, vào
cuộc bầu cử 2014.<br/><br/>Từ nay đến đó, các nhà bình luận lại điểm quân đếm phiếu và luận
về lẽ thắng bại của hai đảng để tác động vào bầu cử theo quan điểm
của họ. Truyền thông của ta thì hồn nhiên dịch lại và đưa lên trang
nhất như tin tức, như chân lý. Người viết xin đi qua chuyện khác.<br/><br/>Chuyện xưa và chuyện sau....<br/><br/><div align="center"><b>* * *</b></div><br/>Chuyện xưa là 60 năm trước, vào năm 1942.<br/><br/>Trong Thế chiến II, quân Nhật tiến vào Đông Nam Á và từ Thái Lan Miến
Điện cắt đường tiếp vận của quân Đồng minh cho Trung Hoa Quốc Dân
Đảng. Khi ấy, có người trình lên lãnh đạo Mỹ một ngả khác đi vào
Trung Quốc. Đó là qua Tây Tạng.<br/><br/>Khốn nỗi, sự hiểu biết của nước Mỹ về đỉnh tuyết này chỉ là kiến
thức từ hồi đấu thế kỷ của Đế quốc Anh. Và trong bộ máy quân sự
của Mỹ, bản đồ Tây Tạng cũng trắng như tuyết.<br/><br/>Đấy là lúc cơ quan OSS, tiền thân của CIA, mới có sáng kiến đưa người
vào tiếp xúc với lãnh đạo Tây Tạng, một cậu bé được coi như
"Phật Sống", để xin mượn đường tiếp vận. Cậu bé đó là đức
Đạt Lai Lạt Ma ngày nay. Hai người được gửi vào là một học giả tốt
nghiệp Princeton và một sĩ quan uyên bác, cháu nội của văn hào Lev
Tolstoy.<br/><br/>Họ vượt núi tuyết tới thủ đô Lhasa, gặp đức Đạt Lai Lạt Ma và được
Hội đồng Nội các gọi là Kashag đón tiếp tử tế. Nhưng vì họ chẳng
có tư cách ngoại giao nên chưa thể đạt thoả thuận gì. Cũng lại
chuyện Bùi Viện cầu viện của ta. Khi trở về, phúc trình của phái
bộ phiêu lưu này được thượng cấp đưa lên Tổng thống F. D. Roosevelt.<br/><br/>Và bị xối nước còn lạnh hơn tuyết giá Hy Mã Lạp Sơn.<br/><br/>Với giọng trịch thượng của kẻ không hiểu biết gì về các nền văn
hóa khác, Rossevelt châm biếm chữ lạ, sánh Kashag với một truyện thời
thượng khi đó tại Mỹ là bài thơ về con bò tím. Và phất tay cho nước
lã ra sông. Chuyện buồn không đoạn kết.<br/><br/>Hoặc đoạn kết còn tục hơn vậy. Sau này cơ quan CIA có yểm trợ Tây
Tạng, nhưng từ "chiến khu" lập ra ở đỉnh tuyết Colorado, bên
Mỹ. Kết cuộc là Tây Tạng không thoát vòng Hán hóa mà lãnh đạo còn
bị Bắc Kinh gán tội là tay sai của CIA. Chuyện đã nhàm vì còn thấy
ở Việt Nam. Người viết đã kể lại chuyện này trong một số Xuân Việt
Báo năm xưa, khi nhắc đến Tây Tạng và đức Đạt Lai Lạt Ma.<br/><br/>Từ chuyện xa xôi đó, sau này, chúng ta mới thông cảm với lời than của
một viên tướng Hoa Kỳ: "Mỗi khi ra quân, chúng ta luôn luôn lầm bản
đồ và ngôn ngữ". Nôm na là thiếu hiểu biết về nhiều yếu tố chi
phối quyết định của lãnh đạo xứ khác, như địa dư, lịch sử và văn
hoá... Vì thế mới dễ quàng xiên.<br/><br/>Ba chục năm sau trò ngu của Roosevelt và việc Hoa Kỳ hy sinh nhiều đồng
minh Âu-Á vì thiếu viễn kiến và hiểu biết mà lại thừa mưu lược,
Tổng thống Richard Nixon có một quyết định lạ vào năm 1973. Khi chuyện
Việt Nam đã thành nước lã ra sông và tiền đồn sắp trôi xuống biển,
mà người Việt mình chưa biết, Nixon muốn có một cơ quan khả dĩ gọi là
"Viễn vọng đài", để đẩy tầm nhìn tới thật xa.<br/><br/>Nixon cho Ngũ Giác Đài lập ra Văn phòng Thẩm lượng Office of Net
Assessment với nhiệm vụ tự bịt tai để khỏi bị nhiễu âm của thời sự
trước mắt mà nhìn vào tương lai. Người phụ trách việc thành lập là
Tổng trưởng Quốc phòng James Schlesinger, một tiến sĩ kinh tế, sau là
học giả, rồi phụ trách về ngân sách, làm Tổng trưởng Quốc phòng cho
hai đời tổng thống Nixon và Gerald Ford rồi Tổng trưởng Năng lượng cho
Jimmy Carter.<br/><br/>Một học giả khác - bạn đồng viện của James Schesinger và nhà vị lai
học khét tiếng Herman Kahn - là Andrew Marshall được chỉ định làm Giám
đốc văn phòng ONA, với trách nhiệm khi ấy là vận dụng trí tuệ của
các chuyên gia để lượng định về hồ sơ hạch tâm với Liên Xô và vạch ra
chiến lược quân sự cho tương lai.<br/><br/>Từ 1973 cho đến nay, bảy đời Tổng thống đều tái bổ nhiệm ông Marshall
vào chức vụ này.<br/><br/>Andrew Marshall sinh năm 1921, tốt nghiệp Kinh tế học từ Đại học
Chicago, là chiến lược gia của nhiều thế hệ. Ông cũng là thượng cấp
đã cất nhắc những người sau này sẽ phụ trách an ninh và đối ngoại
của Hoa Kỳ trong mấy thập niên, như Nguyên Tổng trưởng Quốc phòng (rồi
Phó Tổng thống) Dick Cheney, hay Tổng trưởng và Thứ tưởng Quốc phòng
Donald Rumsfeld và Paul Wolfowitz....<br/><br/>Về công việc, văn phòng lượng định và Andrew Marshall chỉ có nhiệm vụ
tham mưu bên Tổng trưởng Quốc phòng. Họ không có thẩm quyền về chính
sách, chẳng bận tâm về tranh cử, ai lên ai xuống, về giá cổ phiếu
thăng giáng, hay nghị quyết Liên hiệp quốc, Thượng đỉnh Liên Âu hoặc
Đại hội đảng Trung Quốc. Họ cũng không phải hàng ngày trình lên lãnh
đạo về an ninh, tình báo.<br/><br/>Tinh thần chỉ đạo của đơn vị thầm lặng này trong Ngũ Giác Đài là
kỷ luật: lọc cho sạch tiếng ồn của thời sự mà tìm hiểu và dự báo
về những gì sau này có thể đe dọa quyền lợi của Mỹ.<br/><br/>Thời đó, Hoa Kỳ vừa giải vây Trung Quốc mà Chiến tranh lạnh vẫn còn.
Lượng định của ONA nói ngược với sự thẩm định của CIA. Rằng Lợi
tức Quốc gia của Liên Xô chẳng cao như vậy, nhưng mối đe dọa quân sự từ
Moscow thì trầm trọng hơn, nên Hoa Kỳ phải đối phó cách khác. Cũng
thế, ONA ước lượng ngân sách quân sự của Trung Quốc là 140 tỷ, thực
tế cao gấp đôi các con số phổ biến và nếu đi vào trận địa chiến
với Trung Quốc tại Đông Á, Mỹ có thể bị đánh bại!<br/><br/>Cơ quan rất nhỏ bé và rất lạ này chẳng cần lấy lòng Tổng thống,
Tổng trưởng hay Nội các Cộng Hoà hoặc Dân Chủ, chẳng đi theo nhận
thức của đám đông mà lạnh lùng tìm hiểu về địa dư, lịch sử, văn
hóa, kinh tế và kỹ thuật của thiên hạ để thấy ra những động lực
thâm sâu của các nước hay các khối và đoán trước những rủi ro xung
đột với Hoa Kỳ trong một tương lai rất xa....<br/><br/>Những lượng định của ONA đều được trình bày công khai, có đúng có
sai, và vẫn được nhiều giới hữu trách trên thế giới quan tâm. Trong
một cuộc phỏng vấn năm 2012, một chủ biên chính của bốn Bạch thư về
Quốc phòng của Bắc Kinh là Tướng Trần Châu cho biết rằng ông chẳng
hụt một báo cáo nào và Marshall là nhà tư tưởng quan trọng và có
ảnh hưởng nhất đến sự thay đổi tư duy về quốc phòng của Trung Quốc
trong mấy thập niên từ 1990 đến sau này!<br/><br/>Ngẫm lại thì cũng phải.<br/><br/>Khi tìm hiểu địa dư hình thể và lịch sử Trung Quốc, người ta có thể
biết vì sao Bắc Kinh phát triển lực lượng Hải quân từ hai chục năm
trước và bây giờ uy hiếp lân bang. Khi nghiên cứu địa dư hình thể của
đại lục địa Âu-Á, hay quan hệ lâu dài giữa Đế quốc Nga và Âu Châu, ta
dễ thấy trước động thái của tập đoàn năng lượng Gazprom, hoặc việc
Putin tấn công Georgia năm 2008 và ngày nay đang gây phân hóa cho Liên Âu.
Không biết gì về địa dư và lịch sử Ba Tư thì khó hiểu ra trận đánh
Iran-Iraq ngày xưa hay những toan tính đàm phán ngày nay vớ Hoa Kỳ....<br/><br/>Đơn vị nhỏ nhít và kín đáo này nhìn thật xa vào lịch sử, thật sâu
vào địa dư để dự đoán chuyện vị lai trong nhiều thập niên tới. Khi
hữu sự thì ít ra các tướng lãnh còn có bản đồ và không tung quân
vào một trận chiến đã qua, với hình thái quân sự đã lạc hậu.<br/><br/>Ngày nay, ở tuổi 92, ông Marshall vẫn tiếp tục làm việc trong cơ quan
lửng lơ đó. Nhưng nhiều phần thì ông sẽ về hưu sớm khi trận đánh về
ngân sách sẽ cắt cánh Ngũ Giác Đài và cưa chân Viễn vọng đài: vì
thiếu ngân sách, cơ quan Office of Net Assessment có thể bị đóng cửa!<br/><br/><div align="center"><b>* * *</b></div><br/>Tổng thống Barack Obama có thể xúc phạm một đồng minh chiến lược là
Nhật Bản khi chỉ định Caroline Kennedy làm Đại sứ Hoa Kỳ tại Tokyo. Cô
bé bất tài vô tướng và nói năng ngập ngọng này chỉ có cái danh hão
là con gái của John Kennedy, nhưng được Obama đền công trả nợ bằng ghế
đại sứ. Nhiều đời Tổng thống Mỹ cũng đã chỉ định các ân nhân về
tiền bạc hay thế lực chính trị làm đại sứ cho Hoa Kỳ thay vì bổ
nhiệm những nhà ngoại giao chuyên nghiệp đã học bài ở nhà. Cũng
vậy, việc Tổng thống Mỹ hủy bỏ nhiều hội nghị với Châu Á để đấu
võ ngân sách ở nhà đã làm các đồng minh ngao ngán... Nhìn trong lâu
dài thì những vụng về đó rồi cũng sẽ qua, sai lầm được gỡ ra, rồi
cột lại với một tổng thống khác.<br/><br/>Nhưng sự bất biến vẫn là địa dư hình thể và lịch sử của Trung Hoa
và Nhật Bản tại Đông Á, với tác động mới của kinh tế, của khoa học
kỹ thuật, để dẫn tới những rủi ro mới. Khi đó, nước Mỹ có thể bị
văng miểng ra sao?<br/><br/>Chuyện văng miểng đó chưa xảy ra. Chúng ta chỉ thấy rằng Bộ Quốc
phòng Mỹ bị văng một mắt kiếng. Chẳng có bản đồ mà người cận thị
lại đòi cầm súng bóp cò thì chúng ta nên sợ....

### Nguồn:

Viet Bao: https://vietbao.com/a211813/bi-vang-mieng-vao-mat-kieng

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/