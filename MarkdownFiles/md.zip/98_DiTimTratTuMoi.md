# Đi Tìm Trật Tự Mới

10/09/2016

<span><span><br/></span></span>
<div dir="ltr" style="text-align: center;"><span style="font-weight: bold;"><span style="font-size: 18px;">Đi Tìm Trật Tự Mới</span><br/><br/></span></div>
<div dir="ltr" style="text-align: center;"><span style="font-weight: bold;">Nguyễn-Xuân Nghĩa</span></div>
<span><span><br/></span></span>
<p dir="ltr"><span>Trật Tự “Tiền Chiến” Đang Tiêu Vong, Sau Đó Là Gì, Chưa Ai Biết….</span></p>
<span><span><br/><br/></span></span>
<p dir="ltr"><span>Với trực giác hay cảm quan nằm ngoài lý tí, người dân bình thường tại nhiều quốc gia đang thấy thế giới của họ bị sụp đổ, từ kinh tế đến trật tự xã hội. Một số người đã có phản ứng bất thường mà tự phát, và gây lúng túng cho giới lãnh đạo và các phần tử gọi là ưu tú xưa hay vẫn hướng dẫn dư luận và cai trị xã hội. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Cuộc tranh cử tổng thống khá lạ kỳ năm nay tại Hoa Kỳ là một biểu hiện mà không duy nhất. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Đi ngược ánh mặt trời về hướng Đông, tại Âu Châu tình hình cũng tương tự, với sự tan rã chậm rãi của khối Liên Âu sau sáu năm khủng hoảng của đồng Euro. Một triệu chứng khác: tại Trung Đông, nền văn minh Hồi giáo đang trỗi dậy với khuynh hướng cực đoan quá khích và phương pháp khủng bố. Nó thổi lên làn sóng di dân làm Âu Châu thêm bất ổn. Từ đó mà tiến về Nam Á, Trung Á tới Viễn Đông, có điều gì đó đang xảy ra: sự suy yếu của Liên bang Nga, đà quật khởi của Trung Quốc “ngoài cứng trong mềm” hay phản ứng của Nhật Bản bên cạnh bán đảo Triều Tiên với hai nước Nam-Bắc Hàn, có thể dẫn tới xung đột và chiến tranh. Tại vùng biển Đông Nam Á, tình hình còn nghiêm trọng hơn vì tương quan bất lợi của 10 quốc gia trong Hiệp hội ASEAN trước sự hung hăng của Trung Quốc, lần đầu tiên đứng dậy kể từ 180 năm nay, nhưng trên đôi chân đất là nền kinh tế sắp bị khủng hoảng…</span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Đáng ngại hơn cả, ngần ấy biến động lại giàng vào nhau trong thực tế của một thế liên hoàn. Khủng hoảng Hồi giáo từ Trung Đông có thể dội lên Bắc Âu hay Trung Á vào Tân Cương. Khủng hoảng Ukraine từ Liên bang Nga sẽ tác động vào Đông Âu và gây họa cho Liên Âu. Khủng hoảng về nước và cá từ biển Đông Nam Á tràn lên Đông Bắc Á và thách đố khả năng ứng phó của các nước Đông Á lẫn khả năng gián chỉ, can gián, của Hoa Kỳ.</span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Mà cái trục của trật tự toàn cầu thành hình từ sau Thế Chiến II là Hoa Kỳ lại như quay trong chân không, để toàn đại lục Âu-Á sẽ trôi vào hỗn loạn. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Hậu quả là đại lục địa Âu Á, từ Tây Âu qua Đông Á, tiếp cận với Trung Đông và Bắc Phi, có thể bị loạn to, y như thời “Tiền Chiến”, trước Thế Chiến II, cách nay 80 năm. Đại lục này là nơi có năm tỷ người sinh sống – hai phần ba dân số toàn cầu – với các nền kinh tế năng động nhất mà cũng có nhiều võ khí tàn sát nhất. Chúng ta đang trở về thời… Tiền Chiến ngộp thở.</span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>***</span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Về địa dư và lịch sự thì từ nhiều thế kỷ rồi, Đại lục địa Âu-Á từng là trung tâm của thế giới, nhưng là một trung tâm bất ổn với các cuộc khủng hoảng và đại chiến liên tục. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Tại Đông Á thì có Nhật-Hoa và Nhật-Nga Chiến tranh (1894 và 1905) rồi Chiến tranh Thái Bình Dương, Chiến tranh Cao Ly, cuộc chiến Việt Nam. Tại Tây Âu là chiến tranh Pháp Phổ (1871) rồi hai trận Thế chiến (1914-1918 và 1939-1945). Tình hình chỉ tạm lắng đọng sau Thế Chiến II và trong 40 năm “Chiến Tranh Lạnh 1949-1989. Ngoại lệ là… Việt Nam, chỉ tạm hết chiến tranh từ năm 1989 - và nay lại nằm dưới lằn đạn Trung Quốc! </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Ngày nay, khu vực Âu-Á rộng lớn ấy lại đang trở thành một trung tâm bất ổn. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Từ Tây sang Đông, vùng bán đảo Tây-Âu của đại lục đang bị khủng hoảng về kinh tế, chính trị và an ninh. Nằm ngang đại lục là Liên bang Nga, cường quốc rộng lớn nhất, bị suy nhược về kinh tế, dân số và sắc tộc nên lấy rủi ro lớn là cố vùng dậy tại Đông Âu, vào sâu tới Trung Đông, nhưng thực chất vẫn là rỗng ruột. Tình hình Trung Quốc cũng không khác, với bất ổn kinh tế trong tâm can, được che giấu sau sự bành trướng về quân sự trên vùng biển cận duyên. Tại Trung Đông, một vụ khủng hoảng về tư tưởng và an ninh quân sự đang bung ra ngoài thành những mảnh vụn chết người và tư tưởng tự sát. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Vẫn biết rằng mỗi vùng lại có một sắc thái khủng hoảng riêng - Trung Đông khác Trung Quốc! – nhưng nét chung là sự bất ổn và những biến động bất ngờ. Tình hình Âu-Á trong các năm 1930-1936 cũng có những dấu hiệu tương tự, từ Tây Âu qua Đông Bắc Á, với kết qủa cũng bất ngờ là chiến tranh thế giới, là Thế Chiến II. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Xin hãy quay lại khúc phim xa xưa - về thời Tiền Chiến</span></p>
<p dir="ltr"></p>
<p dir="ltr"><span>Thời gọi là “trước Thế chiến” khởi sự từ trăm năm trước, nếu chúng ta suy nghĩ chín chắn rằng Thế chiến I và II chỉ là một, với giai đoạn đình chiến ngắn ngủi là từ 1920 tới 1936. Nhưng vì sao chiến tranh lại bùng nổ? </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Có nhiều nguyên nhân lắm, mà thật ra cũng chẳng khác gì ngày nay. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Thời đó có ba cường quốc nổi lên làm đảo lộn trật tự toàn cầu là Đức, Nhật, Mỹ. Thời đó, nước Nga chưa góp mặt. Ba cường quốc đó cũng chưa góp mặt trong Thế kỷ 19. Chính là sự hùng mạnh của Đức và Hoa Kỳ mới dẫn tới một cục diện khác: chấm dứt sự thống trị của hai Đế quốc Âu Châu là Anh và Pháp. Sau Thế chiến 1 (1919-1920), nước Đức bại trận đã vùng dậy và nước Nhật chiếm ngôi bá chủ Châu Á trước sự bất định và do dự của Hoa Kỳ giữa những thay đổi mới. Sự bất định ấy giải thích vì sao Hoa Kỳ nhập trận rất trễ vào cả hai Thế Chiến (1917 và 1941) khi các cường quốc gia đã lao vào chiến tranh.</span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Hậu quả kinh tế của Thế Chiến I là sự sụp đổ của nước Đức và sự tan rã cơ cấu sản xuất tại hai nước thắng trận là Anh Pháp. Khủng hoảng kinh tế Anh, Pháp, Đức và sự xuất hiện của Liên bang Xô viết sau cách mạng cộng sản đã gây nhiều xáo trộn xã hội và chính trị cho cả Âu Châu. Đấy là lúc chúng ta chứng kiến những chuyện tương tự của ngày nay: Thế chiến II khiến nhiều Đế quốc lớn tan rã, đó là Đế quốc Habsburg, Hohenzollen tại Tây Âu, đế quốc Nga của dòng Romanoff tại Đông Âu và Đế quốc Ottoman tại Trung Đông. Đáng chú ý nhất, nhiều quốc gia vừa giành lại độc lập từ các mảnh vụn đó đã phát huy chủ nghĩa quốc gia dân tộc. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Ngày nay, động lực tinh thần là chủ nghĩa đang manh nha. Ngày xưa, nó góp phần dẫn tới Thế Chiến II trên cả đại lục Âu-Á. Đấy là những chuyển động của thời “Tiền Chiến”. Nếu nhớ lại, thời kỳ mà chúng ta gọi là “Tiền Chiến” chỉ là một sự tan rã của trật tự toàn cầu. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Các Đế quốc Âu Châu bị suy sụp về kinh tế, Đế quốc Xô viết thành hình với nỗ lực kỹ nghệ hóa và tàn sát. Trung Đông rơi vào ảnh hưởng của Anh và Pháp, với nhiều nước Hồi giáo đi tìm giải pháp hiện đại hóa từ nước Đức phát xít. Trung Quốc bị khủng hoảng, nội chiến, xứ sở tan tành vì các lãnh chúa, và bị ngoại xâm: bị Đế quốc Nhật xâm chiếm từ năm 1930.Trong khi việc canh tân và hiện đại hóa nước Nhật, dưới ánh sáng cùa chủ nghĩa dân tộc, lại dẫn đến chủ nghĩa phát xít của một chế độ quân phiệt, hình như đấy lại là kịch bản Trung Quốc ngày nay.</span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Cách xa hiện trường đầy bất ổn đó là hoàn cảnh Hoa Kỳ, vuông vực và phì nhiêu giữa hai đại dương lớn nhất địa cầu. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Khi đó, Hoa Kỳ cũng bị chấn động kinh tế bên trong với vụ Tổng khủng hoảng 1929-1933 nhưng không lui về chủ nghĩa tự cô lập – như người ta đang lo sợ ngày nay. Hoa Kỳ khi đó đã cố gắng can thiệp vào đại lục Âu-Á vì muốn ngăn ngừa một cuộc chiến tại Âu Châu, mà không xong. Khi đó, Hoa Kỳ cũng can thiệp khá tích cực về quân sự lẫn chính trị vào Đông Á, vì là một cường quốc Á Châu mới. Nhưng các biến động tại đại lục Âu-Á đều liên kết với nhau, tác động vào nhau, với Âu Châu, Hoa Kỳ và Liên Xô đều can dự vào Trung Quốc. Khi chiến tranh bùng nổ, nước Mỹ vẫn phải nhập cuộc mà khá trễ, vào cuối năm 1941, sau vụ Trân Châu Cảng - tại Đông Á. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Dù lịch sử không khi nào tái diễn theo cùng một kịch bản, khi những chuyển động lớn của thời xưa lại tái xuất hiện, ta có thể thấy rằng trật tự cũ thành hình từ năm 1945 đang đi vào tan rã. </span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Như những con sâu cái kiến nằm sát mặt đất nêm cảm nhận được sự chuyển động, hay động đất, người dân bình thường của nhiều quốc gia đã hoang mang và bất mãn. Sau đó là gì thì ở trên đỉnh tháp, giới lãnh đạo thật ra chưa biết. Nếu có biết thì cũng sẽ lại tìm cách ngăn ngừa. Nhưng nếu họ thất bại, chuyện của mươi năm tới, chúng ta nên tự chuẩn bị cho những gì đen tối nhất!</span></p>
<span><span><br/></span></span>
<p dir="ltr"><span>Đâm ra, qua năm Đinh Dậu 2017, có khi ta lại nhìn vào Thế giới Ất Dậu 1945, của 72 năm trước. Thiên hạ có thể nhìn vào đó với nỗi lo sợ. Ngoại lệ vẫn là Việt Nam. Dân ta sẽ nhìn vào đó với niềm hy vọng sau những kinh nghiệm bi thảm của mấy chục năm qua….</span></p>
<span id="docs-internal-guid-79f9972c-1492-8709-ef89-ab3fd6b08868"><br/><br/><br/><br/><br/></span><br/>..

### Nguồn:

Viet Bao: https://vietbao.com/a257842/di-tim-trat-tu-moi

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/