# Đánh Trống Bỏ Dùi

24/12/2011

<p>Đánh
Trống Bỏ Dùi</p><p>Nguyễn
Xuân Nghĩa</p><p></p><p>Vào
dịp cuối năm, hãy đếm lại mấy cái dùi trống của Hoa Kỳ</p><p>Cứ
đến cuối năm, truyền thông báo chí Mỹ thường bình chọn biến cố đáng chú ý nhất,
hoặc có ảnh hưởng nhất trong năm. </p><p>Cột
báo này xin đi ngược truyền thống dễ dãi ấy mà chọn một hồ sơ bị lãng quên nhất
trong năm - dù có thể ảnh hưởng đến thời sự năm tới. Cũng là một cách kiểm chứng
lại khả năng nhận xét của chúng ta, thay vì thụ động tiếp nhận thông tin đôi
khi hời hợt, rồi sau cùng lại như dân Mỹ, hốt hoảng la trời khầu hiệu OGM -
"O My God"!</p><p>Hồ
sơ bị lãng quên ở đây là Cộng hoà Tiệp - Czech Republic. </p><p>Nếu
không có vụ cựu Tổng thống Vaclav Havel tạ thế vào cuối năm, người ta quên hẳn
nhân vật vĩ đại này của thế giới. Và thật ra nhiều người Mỹ còn chẳng biết là
Tiệp Khắc đã tự chia đôi từ năm 1993 thành Cộng hoà Tiệp và Slovakia. Lời phán
xét này không vu hồ. Năm qua, một nữ Dân biểu Dân Chủ tại California còn hồn
nhiên phát biểu rằng bà rất hài lòng khi thấy hai miền Nam Bắc của Việt Nam đã
vui vẻ sống chung, dù miền Bắc vẫn còn chế độ Cộng sản và miền Nam tự do là đồng
minh của Mỹ. </p><p>Dân
biểu Maxine Waters có khi đã quên mất biến cố 1975 và được dân chúng khu vực
Los Angeles bầu lên để giải quyết những vấn đề kinh tế hay xã hội của họ dù bà
ta có thể có những quyết định tầy trời cho các xứ khác mà không biết - và khỏi
cần biết.</p><p>"Vô
phúc cho xứ nào cứ nhắm mắt trông chờ vào Hoa Kỳ mà không tự lo lấy thân"!
Lãnh đạo Cộng hoà Tiệp có thể đã nghĩ như vậy - mà dân Mỹ cũng khỏi cần biết. </p><p>Họ
khỏi cần biết rằng đầu tháng 12 vừa qua, Tổng thống Dmitri Medvedev của Liên
bang Nga đã cầm đầu một phái đoàn hùng hậu qua thăm xứ Tiệp trong hai ngày mùng
tám mùng chín. Phái đoàn Nga tới thủ đô Praha hâm nóng quan hệ giữa hai nước
qua ba dự án: 1) xây dựng hỏa xa cao tốc cho Tiệp để nối liền nước Nga với Đông
Âu, 2) phát triển hệ thống trực thăng hỗn hợp giữa hai nước và, quan trọng nhất,
3) dự án xây lò nguyên tử trị giá 25 tỷ tại Temelin.</p><p>Hồ
sơ có vẻ kinh tế đó tất nhiên dễ bị lãng quên nếu người ta không nhìn thấy nhu
cầu hâm nóng quan hệ giữa hai nước. Và một hồ sơ tầy trời khác.</p><p>Từ
đã lâu, Hoa Kỳ vận động việc đón nhận Cộng hoà Georgia và Ukraine vào Minh ước
NATO, sau khi các nước này chuyển hóa sang chế độ dân chủ và muồn hội nhập vào
Âu châu. Khi ấy, cả nước Mỹ đều nói đến cách mạng dân chủ muôn màu tại các quốc
gia từng nằm trong quỹ đạo Liên Xô, như Serbia, Georgia, Ukraine,
Kyrgyzstan.... </p><p>Năm
2008, Chính quyền George W. Bush còn đề xướng kế hoạch phòng thủ chiến lược BMD
tại Ba Lan và Cộng hoà Tiệp, hai thành viên mới của NATO. Đó là lá chắn chiến lược
chống hỏa tiễn đạn đạo, với lý do chính thức là đón bắt hỏa tiễn có thể bắn từ
Iran. Lý do thực tế, nhìn từ Moscow, là để ngăn sự bành trướng của Nga vào khu
vực quỹ đạo truyền thống của Liên Xô. </p><p>Chúng
ta không quên là ngày tám Tháng Tám năm đó, Liên bang Nga đã đưa quân vào
Georgia. Sau đấy còn khuynh đảo nội tình Ukraine là nơi mà một số dân chúng miền
Đông vẫn thiên về nước Nga, còn hai lãnh tụ thân Tây phương, tác giả của cuộc
cách mạng dân chủ màu da cam, thì chia rẽ và tạo cơ hội cho lãnh tụ thân Nga thắng
thế, đương kim Tổng thống Viktor Yanukovych.</p><p>Ngược
với dư luận của nhiều người trong nước, hai Chính quyền Ba Lan và Tiệp đều ủng
hộ kế hoạch BMD không phải nhờ lá chắn chiến lược mà vì lời cam kết - và sự hiện
diện của binh lính Mỹ tại một trạm radar và một hệ thống hỏa tiễn do Hoa Kỳ thiết
trí. Họ đã có kinh nghiệm xương máu với nước Nga ở quá gần! </p><p>Nhưng
họ thiếu kinh nghiệm với Hoa Kỳ. </p><p>Sau
khi nhậm chức, Tổng thống Barack Obama hủy bỏ lời cam kết đó và quăng dự án BMD
vào bàn thương thuyết với Nga. Mục tiêu là để cải tiến quan hệ với Moscow hầu
giải quyết hai ưu tiên của Mỹ: chiến trường Afghanistan và sự hung hăng của
Iran. </p><p>Xin
đọc lại đoạn trên: kế hoạch BMD có lý do chính thức là phát giác và đón bắt hỏa
tiễn Iran có thể bắn vào Âu châu mà thực tế là để ngăn ngừa ám khí của Nga. Bây
giờ, Chính quyền Obama trông cậy vào Nga để can gián Iran và giúp Mỹ có đường
tiếp vận cho chiến trường Afghanistan và hy sinh luôn việc phòng thủ hai đồng
minh Âu châu là Ba Lan và Tiệp.</p><p>Ba
năm sau, là ngày nay, Liên bang Nga tiếp tục nhấn tới. Nga sẽ thiết trí hỏa tiễn
chiến lược ngay tại Kaliningrad, giáp giới với Ba Lan, ngay dưới nách Cộng hoà
Lithuania. Y như Trung Quốc, đến tận cùng, Nga vẫn bên vực Iran và cả Syria.
Moscow còn nhá ra hơn 500 tỷ Mỹ kim dự trữ ngoại tệ để "cấp cứu" Âu
châu trong khủng hoảng, nhân tiện ly gián quan hệ chiến lược giữa Hoa Kỳ và Âu
Châu. </p><p>Trong
bối cảnh đó, kế hoạch BMD coi như chấm dứt và Cộng hoà Tiệp phải cải thiện quan
hệ với Nga. Biến cố ấy đáng quan tâm hơn chúng ta nghĩ vì phản ảnh nhiều chuyện
khác.</p><p>Liên
hiệp Âu châu có thể tan rã, hoặc ít nhất tê liệt trong nhiều năm với các ngân
hàng bị sụp đổ và đồng Euro thành đồng sứt. Khi Ba Lan, nạn nhân của cả hai cường
quốc lân bang là Nga lẫn Đức, mà còn yêu cầu Đức phải có thế mạnh hơn để cứu lấy
Âu châu - chuyện xảy ra cuối năm sau 17 thượng đỉnh Âu châu - ta biết rằng có
gì đó rất đảo điên đã xảy ra tại Âu châu. </p><p>Trước
đó, khi ông Vaclav Havel phải lên tiếng báo động về việc Hoa Kỳ có thể lại hy
sinh đồng minh trong việc đổi chác với Liên bang Nga, ta thấy ra chuyện bất trắc
của cả một khu vực bản lề của Âu châu. Nhưng ngần ấy chuyện lạ không để lại một
ánh chớp trên truyền hình Mỹ. </p><p>Người
dân xứ này lo chuyện kinh tế và thất nghiệp, lãnh đạo thì chỉ thấy một ưu tiên
là cuộc bầu cử và Quốc hội đánh nhau suốt năm mà chưa giải quyết được bài toán
bội chi hay kích thích sản xuất, tăng hay giảm thuế!</p><p>Chuyện
Cộng hoà Tiệp là hồ sơ bị lãng quên trong năm phản ảnh một điều kinh hoàng hơn
vậy: truyền thống đánh trống bỏ dùi của nước Mỹ!</p><p>***</p><p>Ngày
11 Tháng Chín năm 1990, Tổng thống George H. W. Bush (ông Bush cha, Bush 41)
dõng dạc tuyên bố trước Quốc hội sự hình thành của một "Trật tự Toàn cầu mới".
Khi đó, Liên Xô đang trên đà tan rã, từ Iraq lãnh tụ Saddam Hussein vừa mở cuộc
tấn công xứ Kuweit và lực lượng Taliban đã thành hình tại Afghanistan. </p><p>Giấc
mơ "Trật tự Toàn cầu" - New World Order - của lãnh đạo Mỹ, hoặc chuyện
"Lịch sử Cáo chung" của trí thức Hoa Kỳ (học giả Francis Fukuyama) là
một hài kịch. </p><p>Nó
chấm dứt ngày 11 Tháng Chín năm 2001, dưới thời Bush 43 với vụ khủng bố 9-11,
và nó tan tành vào Tháng Tám năm 2008, khi Georgia ngang nghiên bị tấn công mà
không ai nhúc nhích. Sau đó, Hoa Kỳ thời Obama lại còn nuôi giấc mơ khác, là cải
thiện quan hệ với Liên bang Nga để giải quyết chuyện của mình, dù có phải hy
sinh lời cam kết với các đồng minh. </p><p>Kết
quả? </p><p>Hoa
Kỳ rút khỏi Iraq tám năm sau khi xấn xổ bước vào đào xới lung tung. Ứng cử viên
Obama có thêm đóa hoa trên bàn thờ tranh cử. Nhưng, chỉ vài ngày sau khi lá cờ
Mỹ được đưa ra khỏi thủ đô Baghdad, xứ này có loạn! Phe Shia và Iran ở phía sau
thừa thắng xông lên, làm cho hai nhóm thiểu số là dân Sunni và Kurd đều tuyệt vọng.
Kẻ có võ khí mà tuyệt vọng thì bạo động sẽ xảy ra, và thường dân lại chết oan.
Hôm 22 vừa qua, Baghdad lại bị đáng bom làm 72 người thiệt mạng.</p><p>Kết
quả? </p><p>Một
chuỗi quốc gia Đông Âu và Trung Âu được 20 năm tràn trề hy vọng hội nhập vào Âu
châu để tìm sự thịnh vương và nương tựa vào Hoa Kỳ để được bảo vệ. Hy vọng đó
tan loãng với vụ khủng hoảng Âu châu và lời hứa bảo vệ của Mỹ chỉ có giá trị
cho một mùa tranh cử. Xứ Tiệp Khắc từng bị Đức quốc xã tấn công năm 1939, rồi bị
Liên Xô thống trị từ sau Thế chiến II cho đến khi tan rã. Triển vọng hòa bình
và thịnh vượng của các quốc gia này kéo dài được hai chục năm và nay họ đang
nói chuyện phải quấy với một chế độ thực chất là hung đồ đã kê súng vào đầu họ.</p><p>Vì
Hoa Kỳ đang bận chuyện khác! </p><p>Mười
năm trước, cả thế giới nói đến cách mạng dân chủ muôn màu. Làn sóng cách mạng đó
đã bị đẩy lui. Suốt năm nay, người ta cũng ngợi ca mùa Xuân Á Rập và làn sóng
dân chủ trong thế giới Hồi giáo. Với một đống dùi trống ngổn ngang trong một năm
tranh cử tại Hoa Kỳ, người ta nên hoài nghi khả năng hay ý chí thúc đẩy của nước
Mỹ. Những gì đang xảy ra tại Egypt và Libya - chưa nói đến Syria hay Iran - khiến
ta chẳng nên lạc quan, dù là vào một đầu năm mới.</p><p>Dân
chủ hay không là chuyện của người dân ở tại chỗ, chứ không thuộc trách nhiệm của
lãnh đạo hay cử tri Mỹ.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a181634/danh-trong-bo-dui

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/