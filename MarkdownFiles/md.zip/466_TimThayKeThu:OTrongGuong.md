# Tìm Thấy Kẻ Thù: Ở Trong Gương

31/12/2011

<p>Tìm
Thấy Kẻ Thù: Ở Trong Gương</p><p>Nguyễn
Xuân Nghĩa</p><p></p><p>Một
năm lao đao vì nội tình bát nháo...</p><p></p><p>Tổng
kết cuối năm, mỗi người có thể lại nhìn năm 2011 từ một giác độ riêng, tùy mức độ
quan tâm hay... thiệt hại. </p><p>Năm
qua thì quả là một năm có nhiều biến cố gây thiệt hại cho thiên hạ mà không chỉ
do thiên tai, như trận động đất và sóng thần 3-11 tại Nhật Bản hay bão lụt tại
Thái Lan hoặc Phi Luật Tân. Tình hình kinh tế nói chung vẫn chưa sáng sủa và dù
người ta đặt nhiều hy vọng hồi phục của kinh tế Hoa Kỳ, hiệu ứng trầm trọng từ
Âu Châu vẫn còn là một đe dọa cho năm tới. </p><p>Tuy
nhiên, trong một chuỗi dài nhưng đổ vỡ, người ta có thể thấy ra rất nhiều hậu
quả của nhân hoạ còn hơn thiên tai. Xin hãy nói về mấy chuyện đó, và tập trung
vào vài ba khu vực được chúng ta quan tâm nhất.</p><p>Trước
hết là tại Hoa Kỳ.</p><p>***</p><p>Năm
2011 mở ra với kết quả bầu cử hồi Tháng 11 năm 2010: đảng Cộng Hoà chiếm lại Hạ
viện, đẩy lui thế mạnh của đảng Dân Chủ tại Thượng Viện và hạ quyết tâm đánh bại
Tổng thống Barack Obama trong cuộc tổng tuyển cử 2012. Thế rồi, suốt năm 2011,
hệ thống chính trị Mỹ lại có ba đầu và sáu tay đánh nhau loạn xạ. </p><p>Ba
đầu là Hạ viện Cộng Hoà, Thượng viện Dân Chủ và Hành pháp Obama, với ưu tiên là
tái đắc cử nên bán cái cho Quốc hội giải quyết những hồ sơ phức tạp nhất.</p><p>Hậu
quả là trận đánh suốt năm về bội chi ngân sách, định mức đi vay và một chuỗi
ách tắc kéo dài đến cuối năm chưa dứt, trong khi kinh tế chưa khởi sắc, thất
nghiệp còn cao. Trái phiếu Mỹ bị sụt mức tín nhiệm và Quốc hội có tỷ lệ tin tưởng
thấp ngang tầm cỏ, chưa tới 12%.</p><p>Vậy
mà các chính trị gia lại mở tờ lịch sớm hơn quần chúng. </p><p>Khai
diễn năm tới là việc Tiểu bang Iowa bỏ phiếu vòng sơ bộ bên đảng Cộng Hòa vào
Thứ Ba này, biến cố báo hiệu cuộc tranh cử Tổng thống, sẽ chỉ ngã ngũ sau này
sáu Tháng 11 năm 2012.</p><p>Là
người đương nhiệm, Tổng thống Obama không lo tranh cử vòng sơ bộ mà nhắm vào
ngày bỏ phiếu là Thứ Ba sau ngày Thứ Hai đầu tiên của Tháng 11. Trong thế đối lập,
một tá ứng cử viên Cộng Hoà phải giành nhau từ vòng sơ bộ, trước tới Đại hội đảng
vào mùa Thu. </p><p>Đấy
là lúc họ chứng tỏ vì sao cả thế giới nói đến sự lụn bại của nước Mỹ!</p><p>Trong
một bài tổng kết, người viết chỉ có thể ghi vội sự chuyển dịch tâm lý của quần
chúng Cộng Hoà: đó là thành phần cử tri nổi loạn với chính trường ở thủ đô và
chính quyền hiện hành nên... ráo riết hành hạ nhau. Đào Cốc Lục Tiên nữa!</p><p>Mùa
Hè năm nay, nữ Dân biểu Michelle Bachmann là ngôi sao sáng. Rồi thành sao xẹt
khi Thống đốc Rick Perry của Texas xuất hiện. Ông Perry bị phe Cộng Hoà trung
kiên với vị tiền nhiệm là George W. Bush tấn công tơi tả, nhưng gây vạ cho ông
thì chính là cái lưỡi cứng đơ như gỗ! Thống đốc có thành tích mà tranh luận như
người ngậm hột thị và cứ nói là sai bét!</p><p>Nhưng
đảng Cộng Hoà không thiếu người tài! </p><p>Doanh
gia Herman Cain bèn nổi trội với khẩu hiệu tranh cử "không tham gia chính
trị", có thần chú "9-9-9" để giải quyết chuyện quốc kế dân sinh.
Ông trở thành thần tượng của quần chúng bảo thủ và nổi loạn trong đảng. Nhưng
chỉ nổi được một mùa và đỡ không nổi hàng loạt những tai tiếng về mảnh quần hồng.
Quần hào khi ấy lại tìm ra cựu Dân biểu Newt Gingrich như vị cứu tinh. </p><p>Từ
đáy vực, nhân vật đại trí thức, chiến lược gia và công trình sư của nhiều biến
cố chính trị 16 năm về trước đã tái sinh! New Newt! </p><p>Mới
đầu năm thôi, ban tham mưu tranh cử của ông đã tự tan rã và sự nghiệp chính trị
của ông coi như ra ma. Vậy mà Newt vẫn hùng dũng trở về với tài biện luận xuất
chúng! Nhưng cũng chỉ một mùa, mà một mùa bầu cử kiểu đó thì chỉ có vài tuần.
Vì ngần ấy đối thủ Cộng Hoà đã tiền pháo hậu xung và dồn Newt xuống đáy khiến
quần chúng bảo thủ tìm ra người lạ mà quen,Dân biểu Ron Paul của Texas. </p><p>Ứng
cử viên Tổng thống thuộc loại kỳ cựu, mùa nào cũng ra và không qua khỏi ngưỡng
5%, Ron Paul bỗng thành sáng giá vì lập trường tự do tuyệt đối kiểu
Libertarian. Lập trường ấy có nghĩa là thu hẹp sự can thiệp của chính quyền đến
tối thiểu, nên dân bảo thủ mới khoái. Nhưng họ không đếm xỉa gì đến những chủ
trương khác của Ron Paul, phản chiến đến độ ngây ngô khi bênh vực Iran và đề
cao tinh thần tự cô lập của nước Mỹ. </p><p>Ron
Paul không thể có hy vọng và kinh nghiệm còn cho thấy rằng cử tri Iowa thường...
chọn lầm người... Nhưng sáu lần đổi ngựa trước khi vào cuộc đua khiến người ta
hoài nghi khả năng cứu quốc của đảng Cộng Hoà. </p><p>Trận
đánh nội bộ cho thấy những thành phần tích cực nhất trong đảng đều không nhìn
xa hơn những vấn đề họ quan tâm. Mà cũng chẳng xác định được ưu tiên là gì. Là
bảo vệ ý thức hệ bảo thủ, là đánh bại Obama hay cứu lấy nước Mỹ?</p><p>Cho
đến giữa năm, ai cũng có thể nghĩ rằng ông Obama sẽ là Tổng thống một nhiệm kỳ
và bất cứ ứng cử viên Cộng Hoà nào cũng sẽ đánh bại ông ta. Nhờ khả năng tự sát
cao độ, đảng Cộng Hoà có khi sẽ cứu được Obama nếu họ tiếp tục trò sơ bộ kỳ cục
đó.</p><p>Kinh
hãi nhất, người ta thấy ông Obama không là lãnh đạo giỏi trong một khúc quanh
sinh tử của nước Mỹ. </p><p>Trong
nội bộ Dân Chủ, có hai chiến lược gia đề nghị ông rút lui để Ngoại trưởng
Hillary Clinton ra tranh cử, vừa cứu nước vừa cứu đảng mới là vẹn toàn! Một
nhân vật khác, cựu Tổng trưởng Lao động thời Bill Clinton là Robert Reich, thì đề
nghị giải pháp khá hơn: Hillary Clinton đổi ghế với Phó Tổng thống Joe Biden để
đứng chung liên danh làm Phó!</p><p>Ngẫm
lại thì kẻ thù của nước Mỹ chưa chắc đã là các chế độ hung đồ hay độc tài mà là
một số chính khách không biết soi gương. Còn lại, chuyện kinh tế thì đành phó
thác cho thị trường.</p><p>***</p><p>Trong
năm 2011, ai ai cũng nói đến sự suy bại của Hoa Kỳ trước sức lớn mạnh của Trung
Quốc, năm nay đã vượt qua Nhật Bản trở thành nền kinh tế đứng hạng nhì thế giới
sau nước Mỹ. Trung Quốc lại là một xứ độc tài độc đảng nên không có hiện tượng
dân chủ bát nháo như Hoa Kỳ. Với sức mạnh kinh tế và chủ trương bành trướng ảnh
hưởng ra mọi nơi, mô hình Bắc Kinh được một số trí thức Mỹ, thiên tả dĩ nhiên,
coi là gương mẫu!</p><p>Sự
thật lại không hẳn như vậy.</p><p>Ba
mươi năm sau khi Đặng Tiểu Bình tiến hành cải cách kinh tế, chiến lược phát triển
của xứ này đã đi hết giới hạn của nó. Năm tới, những khó khăn kinh tế của thế
giới - và trong ba khối dẫn đầu là Âu, Mỹ, Nhật - sẽ không giúp ích gì cho lãnh
đạo Bắc Kinh. Nôm na là sẽ không ngốn hàng hóa Trung Quốc như trước đây. Nhưng đấy
mới chỉ là chuyện nhỏ.</p><p>Chuyện
lớn là lãnh đạo Bắc Kinh bị áp suất rất nặng ở bên trong. </p><p>Làm
sao kéo mấy trăm triệu dân ra khỏi tình trạng cùng khốn khi đa số người dân lại
bất mãn về mức sống suy sụp vì lạm phát, nạn tham nhũng gia tăng và bất công mở
rộng trong xã hội? Từ Tháng 10 năm ngoái, đảng Cộng sản Trung Quốc đã biết và
ra nghị quyết chuyển hướng để giảm dần sự lệ thuộc vào xuất cảng khi chiến lược
hướng ngoại đã hết công hiệu và thu vét tài nguyên cho dân nghèo có thể dễ thở
hơn một chút.</p><p>Nhưng
từ nghị quyết Tháng 10 năm ngoái đến kế hoạch Tháng Ba năm nay của Quốc hội và
trong suốt năm, họ không thể chuyển hướng được vì bị bó trong một vành ba góc:
lạm phát, bong bóng đầu tư và nạn suy trầm sản xuất. Ở trên là cái vung của môi
trường đang đậy xuống cả nước: nạn ô nhiễm môi sinh và lão hóa dân số khiến
lãnh đạo càng khó xoay trở. </p><p>Muốn
khai thông vấn đề cho dài hạn thì lại bị thực tế trước mắt khép cửa vào mặt. Mà
làm sao chuyển hướng kinh tế trong cái trớn của việc chuyển quyền thừa kế chính
trị? Năm tới, đảng sẽ có Đại hội 18 và những nhân vật sáng giá nhất đều nhắm
vào vị trí sắp tới của mình trong Thường vụ Bộ Chính trị. Y như hiện tượng Hoa
Kỳ, lãnh đạo Trung Quốc bị kẹt trong chính trị nên khó tìm ra giải pháp kinh tế
và xã hội. Nhưng khác với Hoa Kỳ, xứ này không có dân chủ nên dân chúng xoay trở
kiểu khác. Họ nổi loạn! </p><p>Biểu
tình, rồi khiếu kiện tập thể không xong thì có người bạo động, hoặc tự thiêu để
phản đối. Ôn Châu vào giữa năm và Ô Khảm vào cuối năm là hai điển hình của bạo động
tự phát. Ở giữa là những vụ xung đột với "thành quản", cảnh sát và
công an vũ trang....</p><p>Thế
giới bên ngoài thường nói đến mối nguy của Trung Quốc. Lãnh đạo Bắc Kinh nương
theo đó mà xoa dịu nỗi bất mãn của người dân. Trong thâm tâm, họ đã tìm thấy kẻ
thù. Không phải là Mỹ, Nhật, Ấn, Phi, Úc, v.v... hay Nam Hàn với chuyện đổi
ngôi của Bắc Hàn bên bờ vực. Kẻ thù ấy chính là nội loạn ở bên trong.</p><p>Vì
vậy, trong năm tới, chúng ta nghiệm xem xứ nào sẽ sớm bừng tỉnh. Chuyện ấy cũng
là giải đáp cho câu hỏi then chốt rất gần gũi với Việt Nam: nền dân chủ và ách độc
tài, cái gì có hy vọng giải quyết được khủng hoảng?</p>

### Nguồn:

Viet Bao: https://vietbao.com/a181919/tim-thay-ke-thu-o-trong-guong

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/