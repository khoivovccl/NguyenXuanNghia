# Putin và Canh Bạc Ukraine

28/02/2014

Mạnh vì gạo, bạo vì tiền - mà cả hai đều thiếu...<br/><br/>Sau ba tháng biến động có máu đổ, Ukraine bước qua giai đoạn chuyển tiếp - là
bình thường hóa sinh hoạt chính trị trong hoàn cảnh bất thường về cả an ninh lẫn
kinh tế: xứ sở có đầy tai ương này đang bị nguy cơ vỡ nợ - ở bên ngoài thì gặp
họa ngoại xâm.<br/><br/>Sau một Thế vận hội hào nhoáng, Tổng thống Vladimir Putin của Nga gặp thất bại
tại Ukraine bèn lập tức phản công bằng cách biểu dương sức mạnh quân sự. Nga là
cường quốc quân sự chứ không tầm thường, thế giới Âu-Mỹ chẳng nên coi nhẹ sau vụ
Ukraine.<br/><br/>Ta hãy lạnh lùng điểm quân tính số xem chuyện thực hư của tình trạng cực kỳ bất
thường này.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Tại Ukraine, vừa lên nhậm chức thì chính quyền lâm thời, tức là còn non yếu,
báo động thế giới rằng xứ này có thể bị vỡ nợ và cần 35 tỷ đô la, tương đương với
20% Tổng sản lượng cỡ 175 tỷ.<br/><br/>Một cách cụ thể thì hàng tháng, Ukraine phải thanh toán một tỷ đô tiền nhập cảng
khí đốt của Nga, mà nội Tháng Giêng thì đã mất hơn một tỷ trả nợ và một tỷ bảy
tung ra để cấp cứu đồng bạc bị mất giá 15%. Dự trữ ngoại tệ bị hao hụt nặng nên
chỉ đủ cho vài tháng nhập cảng, hay đủ cho việc trả nợ cả năm nay, là 17 tỷ. Vì
vậy, đã có tin đồn là chính quyền hết tiền trả lương bổng và hưu liễm. Đúng lúc
đó, Bắc Kinh nhanh nhảu báo tin là đòi Ukraine trả nợ ba tỷ đô la!<br/><br/>Trong một thế giới bình thường thì Ukraine có thể trông cậy vào 15 tỷ đô la của
Nga và 20 tỷ đô la của Quỹ Tiền tệ Quốc tế IMF để tạm thoát cơn hoạn nạn. Nhưng
thế giới này không bình thường.<br/><br/>IMF và các nước trong Liên hiệp Âu châu đều đồng ý – như đã từng – là cho
Ukraine vay tiền để cứu nguy kinh tế với điều kiện là phải cải cách cơ chế quá
lệch lạc, đầy chứng tật tham ô đã có từ thời xã hội chủ nghĩa. Với những khó
khăn hiện nay của khối Euro, Liên Âu không thể đòi người dân của mình thắt lưng
buộc bụng để cứu nguy các đại gia hay tài phiệt Ukraine. IMF cũng có những quy
tắc viện trợ cấp cứu để chữa bệnh chứ không nuôi bệnh.<br/><br/>Người ta có thể thông cảm với lập trường khắt khe đó.<br/><br/>Nhưng khi chế độ của các đại gia và tài phiệt vừa cáo chung, chính quyền lâm thời
tại Kiev vẫn phải lo cho nạn nhân của chế độ này. Và có thoát cơn nguy khốn thì
mới nói đến việc chấn chỉnh. Đang lúc thập tử nhất sinh trên giường bệnh mà đòi
bệnh nhân kiêng cữ và tập chạy một mình thì đấy là "giải phẫu không có thuốc
mê" - và sẽ làm chính quyền lâm thời lập tức lâm nạn!<br/><br/>Phía bên kia, đầu gấu Putin quả là có hứa cho vay 15 tỷ Euro nhưng cũng với điều
kiện.<br/><br/>Điều kiện đó là chối từ việc hội nhập với Âu Châu mà bước theo Nga vào Liên
minh Quan thuế Âu-Á. Chế độ Viktor Yanukovich chọn hướng đó nên mới gặp chống đối,
và ra lệnh nã súng vào dân nên mới bị lật đổ. Khi biến động xảy ra, Nga đã giải
ngân ba tỷ thì lập tức xiết lại hầu bao nên 15 tỷ đô la vẫn treo lơ lửng, trong
quỹ hưu bổng của dân Nga.<br/><br/>Không chỉ xiết nợ và đòi tiền một xứ láng giềng vừa ra khỏi bóng rợp của mình,
Putin còn chứa chấp lãnh tụ Viktor Yanukovich bị Ukraine truất phế và truy nã,
và biểu dương khí thế côn quang của mình. Đó là cuộc thao dượt quân sự được
thông báo hôm Thứ Tư 26.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Theo chiều kim đồng hồ, Liên bang Nga có bốn Quân khu, mỗi Quân khu do một Thượng
tướng ba sao làm Tư lệnh. Quân khu miền Nam nằm giữa Hắc hải và biển Caspian –
bên trong có Hạm đội Hắc hải tại bán đảo Crimea; Quân khu miền Tây nằm tiếp
giáp với Ukraine, Belarus, ba nước Cộng hoà Baltic và Phần Lan kéo lên mạn cực
Bắc; Quân khu miền Trung trải rộng từ miền Tây đến Trung Á và Tây Bá Lợi Á;
Quân khu miền Đông là cả khu vực Viễn Đông tiếp cận với Trung Quốc, Tây Thái
Bình Dương và tiểu bang Alaska của Mỹ. Lối tổ chức này là do Vladimir Putin ấn
định từ năm 2010 trở về sau khi tiến hành cải cách quân sự.<br/><br/>Hôm Thứ Tư 26, trong khi Ukraine tần ngần đếm lại két bạc cạn đáy thì Tổng thống
Putin rồi Tổng trưởng Quốc phòng, là Thống tướng bốn sao Sergei Shoigu, ra lệnh
tập trận tại Quân khu miền Tây và Quân khu miền Trung, "để trắc nghiệm khả
năng ứng chiến của quân đội Nga - chứ không liên hệ gì đến tình hình
Ukraine".<br/><br/>Trong cuộc cờ này, Putin dàn ra 150 ngàn quân, 90 chiến đấu cơ, 880 chiến xa,
1200 đại pháo và hơn trăm trực thăng. Nhưng các đơn vị của Quân khu miền Nam và
tại Crimea thì "án binh bất động", dù trụ sở Quốc hội Crimea đã bị
phe thân Nga chiếm đóng và phất cờ lung tung. Dĩ nhiên là cờ Nga.<br/><br/>Trong quá khứ, chuyện thao dợt gọi là thường kỳ ấy chẳng có gì là bất thường, nếu
nó không mở màn cho một vụ xâm lấn quân sự. Hồi Tháng Tám năm 2008, trước khi
Putin đưa quân vào hai khu vực tự trị của Georgia là Abkhazia và Nam Ossetia,
Quân khu Bắc Caucasus của Nga cũng đã tập trận nhiều lần!<br/><br/>Rút kinh nghiệm Georgia - điều bất ngờ cho Hoa Kỳ và Liên Âu thời ấy, than ôi -
người ta thấy ngoài trò diễu võ, Putin còn có ngón đòn "con dấu", khắc
bằng củ đậu: Nga rộng tay đóng dấu chứng nhận quốc tịch và thẻ thông hành Nga
cho công dân của hai Cộng hoà Abkhazia và Nam Ossetia. Sau đó, các "công
dân mới" của Nga kêu cứu Moscow đổ quân vào bảo vệ trước nguy cơ đàn áp của
Chính quyền Georgia tại Tbilisi.<br/><br/>Lần này, Putin cũng chuẩn bị con dấu cho dân Ukraine thân Nga tại bán đảo
Crimea.<br/><br/>Vì vậy, dù Putin và Shoigu đều nói cuộc thao dợt không liên quan gì tới Ukraine
và dù Quân khu miền Nam chưa tham dự, người ta vẫn thấy hoài nghi. Putin có thể
muốn tái diễn chuyện Georgia.<br/><br/>Lạc quan hơn theo lý luận phản chiến hay chủ hòa, thì có thể ông ta chỉ cần nhắc
Tây phương và các nước lân bang, rằng Liên bang Nga thời này hết là nước Nga
suy yếu của 15 năm trước.<br/><br/>Ngày nay, Nga đã có thừa khả năng quân sự để trở lại vị trí cường quốc toàn cầu.
Trước tiên là để hoàn thành năm nhiệm vụ chiến lược do Putin đề ra cho quân đội
từ cuộc cải cách năm 2010: 1) tôn trọng luật lệ quốc tế, 2) trong một thế giới
đa cực (thay vì độc bá của Mỹ!), 3) duy trì sự hữu hảo với các nước, 4) mà vẫn
bảo vệ mạng sống và nhân phẩm của công dân Nga - ở bất cứ nơi nào, và 5) xây dựng
ảnh hưởng trong các khu vực trọng yếu cho quyền lợi của Liên bang Nga. Màn biểu
dương quân sự lần này chỉ cần khẳng định năm tôn chỉ có vẻ hiếu hòa kể trên.<br/><br/>Nhưng khốn nỗi hai khoản sau cùng - bảo vệ kiều dân và ảnh hưởng - đều hứa hẹn
chuyện nháng lửa.<br/><br/>Đó là khi kiều dân Nga kêu cứu tại Crimea và khi Tây phương (Hoa Kỳ, Liên Âu và
Minh ước NATO) lại đòi quảng bá những giá trị tinh thần của Âu Châu vào sáu nước
miền Đông còn nằm trong quỹ đạo Nga, là Georgia, Ukraine, Armenia, Moldovia,
Belarus và Azerbaijan!<br/><br/>Số là một năm sau khi Putin đẩy lui đà Tây tiến của Georgia, năm 2009, Liên Âu
phát huy sáng kiến xây dựng thế đối tác với miền Đông (Eastern Partnership) do
Ba Lan và Thụy Điển đề nghị, với hậu quả ngày nay là gây biến tại Ukraine, và
đe dọa "công dân Nga" tại Crimea....<br/><br/>Vì vậy, sau quyết định của Nga tại Crimea và hai Quân khu, các Ngoại trưởng Ba
Lan, Hoa Kỳ, hay Tổng trưởng Quốc phòng Đức cùng Tổng thư ký NATO, v.v... đều
lên tiếng cảnh báo. Và các Tổng trưởng Quốc phòng của 28 thành viên NATO mời
nhau họp hành ngày 27 tại Bruxelles. Chắc là sẽ có những tuyên bố nảy lửa như
pháo ran.<br/><br/>Trong một bài bình luận ỡm ờ ("Lãnh đạo từ sau lưng quần chúng"), người
viết này có gợi ý là Tổng thống Barack Obama nên bất ngờ qua Bruxelles vào ngày
24 vừa qua để vừa hạ nhiệt tại Ukraine và nói chuyện phải quấy với Putin. Dĩ
nhiên là Obama bận chuyện khác và cương quyết lãnh đạo từ đằng sau! Chưa kể là
ông còn cần Putin giải quyết cho mình hồ sơ Syria và Iran, quan trọng hơn cho
nước Mỹ của ông ta.<br/><br/>Đúng lúc đó, lúc này, Tổng trưởng Quốc phòng Mỹ lại đề nghị cắt ngân sách và giảm
quân số Bộ binh tới mức... Tiền chiến, trước Thế chiến II và thời Chiến tranh lạnh.
Lạ chưa?<br/><br/>Cho nên, sau những phát biểu ồn ào, thì Liên Âu sẽ ngỡ ngàng và Ukraine lại bẽ
bàng, và Putin có thể "thu hồi" Crimea do Nikita Krushchev lỡ dại trả
cho Ukraine vào năm 1954. Rồi sẽ nuốt trọn vào bụng mối nguy của người Thát Đát
- Tatars gốc Thổ, theo Hồi giáo. Họ dân bản địa của bán đảo đã từng bị Stalin
tàn sát và đánh đuổi khỏi Crimea và nay không yên tâm khi thấy Nga lại đòi tiếp
thu Crimea.<br/><br/>Nhưng trước khi gạt lệ cho dân Ukraine đáng thương và đáng kính trọng, thì cũng
nên công bằng nhìn vào hầu bao của Putin trong canh bạc có vẻ xả láng này.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Từ năm năm nay, Vladimir Putin có tham vọng hiện đại hóa quân lực và mở tầm ảnh
hưởng ra khỏi khu vực truyền thống của Đế quốc Nga. Tham vọng dễ hiểu của một
cường quốc đã vang bóng một thời. Vang bóng một thời vì quân lực Nga chưa ra khỏi
di hại cộng sản: có vẻ rất mạnh trên nền móng kinh tế rất yếu (nghe cứ như chuyện
Trung Quốc thời nay!)<br/><br/>Sau 15 năm cố gắng của Putin, từ 1999 đến nay, quân lực Nga vẫn thuộc loại lạc
hậu, về trang bị, kỹ thuật và khả năng. Muốn có cái lực cao bằng cái thế, Putin
vẫn phải chọn ưu tiên là gạo hay súng, kinh tế hay an ninh. Như các lãnh tụ Xô viết,
ông ta đã chọn. Và càng tự tin là làm được khi Tổng sản lượng của Nga đã tăng
hơn gấp bảy trong 10 năm, từ hơn 300 tỷ năm 1995 đến nay là 2.200 tỷ.<br/><br/>Nhưng chuyện cụ thể là sẽ phải gia tăng ngân sách quốc phòng chừng 700 tỷ đô la
trong 10 năm, so với 90 tỷ hiện nay. Với điều kiện là dầu thô vẫn trên trăm bạc
một thùng. Ngân sách quân sự của Nga được dự phóng trên kịch bản là dầu thô ở mức
117 đô la. Là chuyện hết còn! Chưa kể là 63 trong 83 địa phương của Nga, từ các
tỉnh, oblast đến các nước Cộng hoà linh tinh, đều bị bội chi, mắc nợ và có thể
vỡ nợ nếu không được trung ương cấp cứu.<br/><br/>Ngoài giới hạn về ngân sách, phải tăng đến độ hụt hơi như Mikhail Gorbachev đã
gặp sau mấy thập niên duy ý chí của Leonid Brezhnev, Putin còn bị kẹt là... thiếu
người.<br/><br/>Khả năng trưng binh có hạn cho một dân số bị lão hóa, mà nếu có tăng lương lính
để tuyển người thì kẹt ngân sách. Nga thiếu 300 ngàn để giữ quân số ở mức 800
ngàn như trù tính. Chi tiết bất ngờ ấy là con bài rất bèo trong canh bạc.<br/><br/>Giới hạn thứ ba còn chết người hơn. Hệ thống trang bị quân sự của Nga bị lỗi thời
ít ra một phần tư. Ba phần tư là tàn dư sản xuất từ thời Xô viết. Vào năm 2010,
Chỉ tiêu của Putin là trong 10 năm phải hiện đại hóa được 70%, mỗi năm nâng cấp
11% cho tới năm 2020. Chưa nói đến yếu tố kỹ thuật hay công nghệ chiến tranh, cả
một hệ thống tiếp liệu và sản xuất võ khí của Nga vẫn bị ngộp trong quy cách Xô
viết, và quyền lợi cục bộ đính kém từng phẩm vật.<br/><br/>Nói theo ngôn ngữ cờ bẻo, đấy không là con tẩy xì mà là tẩy sất. Lá bài lủng.<br/><br/>Cho nên, Liên bang Nga của Putin có thể uy hiếp được Ukraine và thôn tính bán đảo
Crimea. Nhưng nếu muốn vươn ngang tầm cao thời đại thì sẽ lại bắt trớn Liên Xô.
Vì lực bất tòng tâm nên hụt hơi mà chết. Khi ấy, chúng ta mới nhớ đến cuộc thi
đua võ trang cuối thời Chiến tranh lạnh. Ngày nay, nếu Hoa Kỳ mà suy tính như vậy
thì quả là ác liệt.<br/><br/>Mà hơi ác....

### Nguồn:

Viet Bao: https://vietbao.com/a217926/putin-va-canh-bac-ukraine

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/