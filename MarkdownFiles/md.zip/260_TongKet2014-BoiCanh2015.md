# Tổng Kết 2014 - Bối Cảnh 2015

04/12/2014



### Nguồn:

Viet Bao: https://vietbao.com/a230502/tong-ket-2014-boi-canh-2015

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/