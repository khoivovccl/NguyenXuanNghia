# Bầu Cử Tại Trung Quốc

20/06/2011



### Nguồn:

Viet Bao: https://vietbao.com/a173236/bau-cu-tai-trung-quoc

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/