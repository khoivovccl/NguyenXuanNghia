# Thống Kê Trung Quốc và Ảo Giác Quốc Tế

21/01/2016



### Nguồn:

Viet Bao: https://vietbao.com/a248319/thong-ke-trung-quoc-va-ao-giac-quoc-te

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/