# Bi Kịch Palestine

21/05/2011

<p>Bi
Kịch Palestine</p><p>Nguyễn
Xuân Nghĩa</p><p>Những
mộng ước bất khả trong một thảm kịch lớn...</p><p>Sau
bài diễn văn hôm 19 về đối sách của Hoa Kỳ trong khu vực Á Rập Hồi giáo, và vụ đụng
độ nháng lửa hôm sau với Thủ tướng Israel là Binyamin Netanyahu, Tổng thống
Barack Obama chuẩn bị qua Âu Châu trong năm ngày công du, từ 23 đến 27, để giải
quyết nhiều vấn đề của Âu Châu và mối quan hệ với Liên bang Nga. Chuyện Âu
Châu, tuần sau ta sẽ tính. </p><p>Kỳ
này, xin tìm hiểu về dự kiến của Tổng thống Mỹ tại khu vực Á Rập, nhất là một hồ
sơ nan giải trong khu vực có tên là "Levant", miền Đông của Địa Trung
hải. Với Âu Châu và Pháp - tác giả của chữ này tư thời Trung Cổ - đó là nơi mặt
trời mọc, là bậc thềm tiến về Châu Á.</p><p>Quan
trọng nhất, đó là đất sống của dân Do Thái từ thời Thượng cổ và ngày nay là
vùng tranh chấp của xứ Israel với dân Palestine.</p><p>Trong
bài diễn văn dài 45 phút hướng về dư luận bên ngoài, Tổng thống Obama trình bày
niềm tin của mình về một trào lưu dân chủ tất yếu trong thế giới Á Rập, mà Hoa
Kỳ có nhiệm vụ yểm trợ. Bỏ bên ngoài những lý do chính trị nội bộ, quan điểm của
ông thật ra không khác với chủ trương của vị tiền nhiệm George W. Bush và lý luận
của cánh "tân bảo thủ": Hoa Kỳ phải phát huy dân chủ để có hòa bình
khi người dân xứ khác được tự do. Và ông tin rằng những biến động từ gần sáu
tháng nay trong khu vực Bắc Phi và Trung Đông là biểu hiện của trào lưu dân chủ.</p><p>Người
ta có quyền đồng ý hay không về cách nhận định và diễn giải - narrative - của ông
vềbiến cố này. Nhưng khi giàng hồ sơ
Palestine vào kịch bản dân chủ hóa, có khi Tổng thống Mỹ lại gặp hậu quả bất lường
và rủi ro lớn. </p><p>Vì
hồ sơ này quá phức tạp, chúng ta cần nhìn ra bối cảnh và các yếu tố loạn hay trị
tiềm ẩn bên trong.</p><p>***</p><p>Thứ
nhất, xin nói về định nghĩa. </p><p>Chúng
ta có dân tộc Do Thái - người Jews - hậu thân của người Do Thái cổ- Hebrew - và ngày nay có quốc gia Israel của
dân Do Thái. Từ thời Thượng cổ và trong Thánh Kinh, dân Do Thái đã sinh sống,
bành trướng, chiến đấu và bị đầy đọa nhiều lần trong khu vực này. Sau mấy ngàn
năm như vậy và cho tới thế kỷ XX, dân Do Thái phát triển một bản năng sinh tồn
rất mạnh khiến nhiều người khâm phục mà cũng làm nhiều người nghi ngại, thù
ghét.</p><p>Còn
lại, dân Á Rập trên đất Palestine - gọi là dân Palestinian - thì xin giải thích
sau vì liên quan tới địa dư và lịch sửlà chuyện kế tiếp.</p><p>Về
địa dư, khu vực Levant, ngày nay cũng được gọi là "Trung Đông", nằm từ
ven biển hướng Đông của Địa Trung hải vào tới lưu vực sông Jordan và đồi núi
vây quanh. Phía Bắc có xứ Lebanon và Syria, phía Đông có sa mạc Syria của Bán đảo
Á Rập, phía Tây Nam là sa mạc của Bán đảo Sinai thuộc xứ Ai Cập. Đây là khu vực
bao trùm hay tiếp cận với các quốc gia là Lebanon, Syria, Jordan, Israel và Ai
Cập, Egypt.</p><p>Thứ
ba, xin nói về lịch sử, với hai dấu mốc là hai cuộc Thế chiến của thế kỷ XX.</p><p>Trong
bốn thế kỷ từ 1517 đến 1919, khu vực Levant là một tỉnh của Đế quốc Hồi giáo
Ottoman, gọi là tỉnh Syria. Khi Đế quốc Ottoman liên kết với nước Đức trong Thế
chiến I và năm 1919 tan rã cùng sự bại trận của Đức, khu vực Levant rơi vào
vòng kiểm soát - chia chác - của hai cường quốc "chiến thắng" tại Âu
Châu là Anh và Pháp. Chuyện ấy gieo mầm cho những tai họa ở đây, khi họ trao
cho các thị tộc thiểu số quyền cai trị trên từng vùng đất được gọi là "quốc
gia" theo quan điểm của Âu Châu, trên những lãnh thổ chưa có quốc dân. </p><p>Bây
giờ gom lại cả tấm bản đồ và cuốn lịch, ta có thảm kịch Palestine.</p><p>Từ
năm 1916, mật ước Anh-Pháp gọi là Sykes-Picoty - có sự đồng ý của Đế quốc Nga -
đã chuẩn bị thực đơn sáu món về lãnh thổ của Đế quốc Ottoman: sau khi đánh gục
Ottoman thì chia xứ này thành nhiều mảnh! Sau Thế chiến I, riêng tại khu vực
Levant, Anh và Pháp cắt nhỏ tỉnh Syria rồi gom lại thành nhiều nước được ban
cho các thị tộc đã yểm trợ họ trong Thế chiến. </p><p>Thuộc
quyền giám hộ của Pháp, phía Bắc tỉnh Syria được cắt riêng thành nước Syria. Nhưng
Pháp xắn một phần của Syria thưởng cho hệ phái Thiên chúa giáo Maronite lập ra
nước Liban hay Lebanon, là tên một rặng núi. Quốc gia Lebanon thành hình mà thật
ra chưa có quốc dân thống nhất, còn Syria coi Lebanon là phần đất của mình, nơi
mình có quyền can thiệp và khai thác. </p><p>Quản
lý phía Nam tỉnh Syria cũ, Anh trao quyền lãnh đạo cho dòng Hashemite trên cả
khu vực Levant và Bán đảo Á Rập. Khi dòng Saudi chiếm phân nửa và lập ra xứ
Saudi Arabia từ giữa năm 1920, Anh tưởng thưởng dòng Hashemite phần còn lại của
bán đảo Á Rập để lập ra Vương quốc Trans-Jordan, là nước Jordan này nay, và
vùng đất sau này sẽ là cường quốc Iraq. </p><p>Trong
cả khu vực, một deo đất hẹp nằm tại miền Nam núi Hermon và Tây ngạn sông Jordan
đã là một huyện của tỉnh Syria, xưa kia là đất "Filistia" do tên của
dân Philistine mà người ta có thể đọc thấy trong Thánh Kinh. Hai nước Anh và
Pháp lấy lại tên cũ mà gọi đó là đất Palestine.</p><p>Chưa
hết nhức đầu. </p><p>Khu
vực Levant này là của dân Á Rập, thuộc thị tộc này hay hệ phái kia, nhưng đều
theo Hồi giáo, không thuộc sắc tộc Ba Tư như Iran hay Thổ như Turkey. Tuy vậy,
mẫu số chung là "Á Rập Hồi giáo" chưa kết tinh thành một cộng đồng quốc
gia như ta hiểu ngày nay mà vẫn có những dị biệt và tranh chấp về thị tộc và hệ
phái tôn giáo lẫn thể chế chính trị, là thế quyền hay thần quyền, quân chủ hay
"dân chủ", v.v....</p><p>Khi
các thị tộc lớn của dân Á Rập đều được trao đất thành lập ra các quốc gia, dân
Á Rập trên đất Palestine bị bỏ quên. Họ bị các quốc gia Á Rập kia bỏ rơi, nghi
ngờ và xua đuổi, chẳng khác gì dân Do Thái cũng lần mò về đó sinh sống!</p><p>Xứ
Syria coi đất Palestine y như Lebanon và Jordan: thuộc chủ quyền của mình mà bị
Âu Châu xén mất. Còn dân Palestine thì chỉ là thần dân của Syria. Nói đến một
quốc gia độc lập cho dân Palestine là có sự phản đối của Syria! </p><p>Dòng
Hashemite ngựtrên đất lạ là Jordan thì
cũng coi đất Palestine này là của mình. Thực tế thì Vương quốc Jordan đã chiếm
Tây ngạn sông Jordan, sau này cứ được gọi tắt là West Bank, và phía Đông của
Thánh địa Jerusalem, là hai vùng ngụ cư của dân Palestinevì Israel chiếm cứ từ
1967. </p><p>Thật
ra, xứ Jordan không muốn Palestine biến thành một quốc gia, đã hai lần từ chối
việc đó vào năm 1948 và 1967 và một lần tàn sát dân Palestine sống tại Jordan, đẩy
họ qua xứ Lebanon (năm 1970). Nỗi lo của dòng Hashemite là dân Palestine từ hướng
Tây dạt qua sẽ sinh con đẻ cái tại Jordan và có ngày đảo chính vương quyền, là điều
đã xảy ra mà không thành, thành tích của Yasser Arafat và tổ chức PLO!</p><p>Cách
đất Palestine một sa mạc Sinai, xứ Ai Cập cũng không yên tâm với dân Palestine
vì cho rằng đất Palestine này là một phần lãnh thổ của "Cộng hoà Á Rập Thống
nhất", do Ai Cập lập ra với Syria! Rất kỵ quốc gia Israel từ ngày thành lập
vào năm 1948, Ai Cập lại trông cậy vào dân Do Thái và Chính quyền Israel để
Palestine không thể trở thành một quốc gia độc lập.</p><p>Nhưng
ngần ấy quốc gia đều khích lệ tinh thần độc lập của dân Paalestine để phát huy
sức mạnh Á Rập Hồi giáo chống lại một "kẻ thù chung" mà rất được việc.
Là dân Do Thái và xứ Israel! </p><p>Ngay
sau ngày lập quốc thời 1948, dân Do Thái tại chỗ đã đón nhận di dân và đồng bào
của họ để củng cố quốc gia Israel. Trong khi đó, cũng từ ngày ấy, dân Palestine
bị đồng bào Á Rập của họ tại các nước lân bang xua đuổi, và chỉ được gom vào
hai tụ điểm là Tây ngạn Jordan và Dải Gaza, để ca bài hát chống Do Thái.</p><p>Sự
thâm hiểm của Anh và Pháp từ 1916 đến 1967 chỉ thua kém sự gian ác của các nước
Á Rập chung quanh từ 1967 cho đến nay! Không nhìn ra điều ấy mà cứ phê phán
chuyện Palestine thì khó hiểu ra nỗi khó của Hoa Kỳ!</p><p>***</p><p>Bây
giờ đến chuyện xứ Israel của người Do Thái.</p><p>Đa
số truyền thông Mỹ và cả thế giới cứ nói đến nhóm vận động Do Thái
("Jewish Lobby") trong chính trường Hoa Kỳ. Họ ít đọc lại lịch sử và
quên mất địa dư của khu vực Levant.</p><p>Trên
đà sụp đổ của Đế quốc Ottoman, Đế quốc Anh thời đó muốn kiểm soát khu vực
Levant và vì vậy mới cùng Pháp chia nhau xả thịt tỉnh Syria thành từng mảnh như
đã nói ở trên. Qua Thế chiến II, có hai đại cường khác cũng ngó vào vùng đất
trung chuyển giữa Âu và Á, Tây và Đông, đó là Liên Xô và Hoa Kỳ. Vì vậy, song
song cùng tranh chấp và đấu lực tại Hy Lạp và Thổ Nhĩ Kỳ, hai nước lãnh đạo Chiến
tranh lạnh cùng ngó vào đất Levant của Đế quốc Anh đang suy tàn, và Thực dân
Pháp đã hết thời.</p><p>Chính
là hai xứ này đã gây sức ép với Anh và vận động sự thành lập của quốc gia
Israel. Chủ nghĩa Zionism và tinh thần độc lập của dân Do Thái đã khôn khéo
khai thác chiều hướng này. Đây là chuyện khác, sẽ tìm hiểu trong dịp khác.</p><p>Liên
Xô ủng hộ sự thành lập quốc gia Do Thái với dân định cư có cùng... ý thức hệ. Đa
số di dân Do Thái bước vào đất Israel là đến từ Nga, với quan niệm xây dựng
nông trại theo kiểu "đồn điền" - vừa sản xuất vừa chiến đấu - và phát
huy mô thức "công xã" của Liên Xô. Nhìn lại thì người dân lập ra quốc
gia Israel thì đến từ Nga, tiền bạc do dân Do Thái tại Mỹ chung góp một phần!
Sau này, Israel mới là mảnh đất của dân Do Thái đến từ tứ xứ.</p><p>Nhớ
lại thì từ năm 1948 cho đến 1967, Israel là một nước thân Xô viết, chống Mỹ, được
Pháp yểm trợ và gây khá nhiều vấn đề cho Hoa Kỳ. Vụ khủng hoảng Kênh đào Suez năm
1956 là một nhắc nhở. Sau năm 1967, Hoa Kỳ mới đảo ngược quyết định, khi Israel
mất chỗ tựa vào nước Pháp và tách dần khỏi ảnh hưởng Xô viết. </p><p>Trong
54 năm liền, ảnh hưởng rất lớn của dân Do Thái tại Mỹ chưa từng khiến nước Mỹ lấy
những quyết định có lợi cho Israel mà có hại cho quyền lợi của Hoa Kỳ - là định
nghĩa của "chi phối". Dân Do Thái cũng không có khả năng chìm hay nổi
để chọn người lên lãnh đạo nước Mỹ, tiến trình tuyển cử và bầu bán quá phức tạp
của một xứ quá đa diện như Hoa Kỳ hoàn toàn vượt qua khả năng của các phù thủy
Do Thái.</p><p>Và
ngày nay, đa số dân Do Thái, từ tài phiệt đến trí thức và nghệ sĩ cùng các hiệp
hội của họ tại Mỹ dồn tiền ủng hộ đảng Dân Chủ và có lập trường khá nghiêm khắc
với Chính quyền Israel. Chỉ có một thiểu số là dồn phiếu bên Cộng Hoà để bảo vệ
Israel. </p><p>***</p><p>Ở
tại chỗ, Israel có khả năng tự vệ chống lại mọi cuộc xâm lược của các lân bang,
nhờ địa dư hình thể và thực lực của các lân bang này. </p><p>Muốn
tấn công Do Thái từ hai ngả Đông Tây thì phải vượt qua sa mạc Negev và sa mạc
Sinai, là điều bất khả cho cả Jordan và Ai Cập. Hai xứ này đã trả giá cho việc
thử nghiệm đó. Muốn tấn công từ mạn Bắc, Syria không thể vượt qua núi mà chỉ
còn khoảng trống vài chục cây số,từ Cao nguyên Golan tới biển Galilee, và sẽ bị
du kích Israel cho phơi thây trên sông Jordan. Còn lại chỉ có xứ Lebanon phía Bắc
- và lực lượng Hezbollah ở phía Nam Lebanon - có thể vượt sông Litani và pháo
kích vào lãnh thổ Israel. Nhưng khu vực này là vùng buôn bán cần thiết cho
Lebanon với các nước Địa Trung hải và Lebanon không dại gì hy sinh sự phồn thịnh
của mình để vẽ lại bản đồ Israel cho dân Palestine! </p><p>Trừ
phi có sự xúi giục của một cường quốc ở xa là Iran, qua trung gian của lực lượng
Hezbollah và xứ Syria...</p><p>Bên
trong, người Do Thái miền duyên hải và miền Bắc thì giỏi buôn bán và có tinh thần
hiếu hòa hơn là dân Do Thái ở phía Đông, vốn dĩ thường xuyên ứng chiến từ thời
lập quốc 1948. Phe "diều hâu" Do Thái ở phía Đông cũng cần đất sống
và hàng rào phòng ngự nên lấn dần vào Tây ngạn sông Jordan là nơi sinh hoạt của
dân Palestine do Israel kiểm soát từ năm 1967 sau khi chiếm của Jordan. Còn lại,
dân Palestine chỉ có deo đất hẹp ở hướng Tây Nam là Dải Gaza, nay thuộc quyền
kiểm soát của lực lượng Hamas, nổi tiếng với phương pháp khủng bố và chủ trương
tiêu diệt quốc gia Israel.</p><p>Về
mặt phòng thủ, Israel có đủ sức tự vệ trước áp lực của các nước Á Rập vây
quanh, nhưng không thể cưỡng lại áp lực của các đại cường ở xa, như Hoa Kỳ hay
Liên Xô. Chuyện gần là tự vệ thì Chính quyền Tel Aviv còn giải quyết được bằng
quân sự, chứ chuyện đối phó với các đại cường ở xa thì phải dùng phương pháp
ngoại giao.</p><p>Ngoại
giao để từ chối lui về biên cương 1967 tức là ra khỏi Tây ngạn sông Jordan, là điều
Thủ tướng Netanyahu nói thẳng tại cuộc họp báo với Tổng thống Obama trưa Thứ
Sáu 20. Lui về đó là hết đất phòng thủ trước một số khuynh hướng Palestine cực đoan
chỉ muốn tiêu diệt xứ Israel. Ngoại giao để cho thấy dân Palestine ở Tây ngạn
sông Jordan chỉ có tương lai và sinh hoạt kinh tế nếu hợp tác với Israel và được
Chính quyền Tel Aviv yểm trợ. Ngoại giao để chứng minh rằng khu thị trấn trên Dải
Gaza không có tương lai kinh tế và dân cư cũng chẳng có thể ra khỏi khu vực này
để kiếm ăn nơi khác nếu tiếp tục ủng hộ lực lượng Hamas.</p><p>Nhìn
như vậy thì việc thành lập một quốc gia Palestine, như Tổng thống Obama chủ trương,
là điều nan giải trong thực tế. Như đã nói ở trên, các nước Á Rập chung quanh
không thật lòng với viễn ảnh đó. </p><p>Còn
lại, một quốc gia Palestine với hai mảnh Gaza và West Bank thì sẽ có hai đầu và
có ngày chia hai như Pakistan và Bangladesh năm 1971. Khu vực Gaza là những thị
trấn chật chội thiếu tài nguyên trừ nhân lực nheo nhóc sẽ không có kinh tế mà
chỉ có cứu trợ. Khu vực West Bank thì có hy vọng hơn, nhưng còn tùy vào nguồn
nhân lực là di dân từ Gaza đi qua, dưới sự kiểm soát của Israel. Nếu lãnh đạo
Palestine có thiện chí và thống nhất chủ trương hiếu hòa để sống chung thì may
ra giải pháp quốc gia Palestine tại West Bank còn có thể thành hình, với sự yểm
trợ, nuôi dưỡng và kiểm soát của Israel.</p><p>Nhưng,
chưa tiến tới thống nhất ý kiến trong hai nhóm Palestine - ôn hoà theo Fatah tại
Tây ngạn và cực đoan theo Hamas tại Dải Gaza - mà đã nói đến việc thương thuyết.
Và chưa thương thuyết mà đã đòi Israel phải trở về vị trí của năm 1967 thì cũng
tựa như đòi xứ Israel tự sát. </p><p>Nhẹ
nhất, nếu là một chiến thuật thương thảo do Hoa Kỳ đề nghị thì chiến thuật này
sẽ thất bại vì chỉ khuyến khích xu hướng cực đoan của dân Palestine là đòi
Israe, nhượng bộ thêm.</p><p>Kết
luận ở đây là dân Palestine chính là nạn nhân của các nước Á Rập Hồi giáo và hy
vọng của họ lại nằm trong tay kẻ thù, là chính quyền Israel của dân Do Thái. Cứu
tinh của họ, có thể làm Israel bị khuất phục chính là Hoa Kỳ. </p><p>Nhưng
giả thuyết ấy mà xảy ra, Israel sẽ không tự sát và toàn khu vực Levant sẽ thành
biển lửa!</p>

### Nguồn:

Viet Bao: https://vietbao.com/a171951/bi-kich-palestine

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/