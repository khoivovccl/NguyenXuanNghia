# Thế Giới Và Việt Nam Sau TPP

02/02/2017



### Nguồn:

Viet Bao: https://vietbao.com/a263587/the-gioi-va-viet-nam-sau-tpp

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/