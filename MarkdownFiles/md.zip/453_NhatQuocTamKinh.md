# Nhất Quốc Tam Kinh

10/03/2012

<p>Ba
nỗi thất kinh của lãnh đạo Bắc Kinh</p><p>Trung
Quốc có nền kinh tế được tiếp nước biển để đi xe đạp. Xe không lăn bánh là đổ,
và đảng lăn. Người viết thường lý luận như vậy nên đã... thành nhàm.</p><p>Trung
Quốc cũng là một quốc gia mà có ba nền kinh tế. Đó là chuyện "nhất quốc
tam kinh". Trên cột báo này, người viết đã nói về chuyện đó từ nhiều năm
nay, nhưng vẫn phải nhắc lại. </p><p>Vì
địa dư hình thể không lấy chi làm "thiên thời địa lợi", xứ này có ba
khu vực địa dư khác biệt nên đang sợ chuyện... nhân bất hòa. </p><p>Thứ
nhất, vùng duyên hải miền Đông - nơi có độ ẩm đủ cao cho việc canh tác, trở
thành khu vực tập trung Hán tộc, đất "Trung Nguyên" - là cửa sổ thông
thương ra ngoài sau thời "cải cách" 30 năm trước. Người dân nơi đây
có mức sống tương đối cao hơn cả, nhưng ở vào hoàn cảnh "đất chật người đông".
Diện tích canh tác của xứ này chỉ bằng một phần ba của trung bình thế giới cho
nên dù có Thượng Hải hay Quảng Châu rất hoành tráng, Trung Quốc chỉ đủ sức vặt
mũi bỏ mồm. Và phải nhập cảng lương thực.</p><p>Tiến
về hướng Tây là khu vực hoang vu bạt ngàn của những tỉnh lạc hậu, đông dân, bị
khoá trong đất liền và thiếu phương tiện vận chuyển. Mức sống rất thấp khiến vựa
người lầm than ở đấy vẫn phải Đông tiến để kiếm sống, hay làm loạn, một định
nghĩa khác của "cách mạng". </p><p>Cả
triệu "dân công", những người lưu tán từ quê hương nghèo nàn qua các
tỉnh thành miền Tây, đang trở thành vấn đề, như đã từng là khi Mao Trạch Đông
qua đó vét quân trong cuộc "Vạn lý Trường chinh" để vào làm chủ Trung
Nguyên.</p><p>Sau
cùng là khu vực ngoại biên ở chung quanh, theo chiều kim đồng hồ là từ Cao
nguyên Thanh Tạng phía Tây Nam đến Tậy Tạng, tới đất Đông Thổ, hay là Tân Cương
theo cách gọi mới từ 1949, rồi vùng Nội Mông và đất Mãn Châu phía Bắc. Khu vực
thứ ba này còn nghèo hơn các tỉnh miền Tây, mà cũng là vùng trái độn chiến lược
của Trung Quốc. Chữ "đồn điền" được phát minh là cho vùng đó, lính
làm lực điền để bảo vệ cái đồn.</p><p>Trong
lịch sử, bọn "Tứ Di" hay các dị tộc man rợ đã từng từ vùng biên vực
này tiến vào làm chủ Trung Nguyên. Chuyện Hung Nô, Tây Hạ, Liêu, Kim, Mông, Mãn
vào đội mão Thiên tử là những trang sử lạnh mình - và mất mặt - cho Thiên triều.
Vạn lý Trường thành từ thời Chiến quốc đến Cường Tần hay Đại Minh chính là biểu
hiện vĩ đại của nỗi sợ hãi đó từ vùng biên vực.</p><p>Từ
hơn nửa thế kỷ nay, chế độ Cộng sản vẫn chưa giải quyết nổi bài toán hội nhập
ba vùng và kinh tế vì vậy vẫn cứ chia ba. Trung ương ở miền Đông tương đối trù
phú vẫn phải quăng tiền đấm mõm miền Tây để tránh động loạn, và đưa quân vào kiểm
soát khu vực ngoại biên để ngăn ngừa tai họa ngoại nhập.</p><p>Nhưng
tai hoạ còn nguyên vẹn, vì thế lãnh đạo Bắc Kinh thời nay mới có ba điều kinh
hãi....</p><p>***</p><p>Nỗi
lo số một của các đấng con trời ngày nay là nội loạn. </p><p>Việc
ngân sách của cảnh sát và an ninh nội chính lại còn cao hơn ngân sách của quân đội
là một biểu hiện. Chế độ hộ khẩu tai ác và vô cùng bất lợi cho sinh hoạt kinh tế
lẫn đám "dân công" mà vẫn được duy trì cũng là vì mục tiêu kiểm soát.
Nơi đáng lo ngại nhất là miền Tây lạc hậu và nghèo nàn, vùng sinh hoạt của các
dị tộc trong những đặc khu tự trị hành chánh. </p><p>Sau
thời mở cửa, kế hoạch "Tây tiến" của thế hệ lãnh đạo thứ ba là Giang
Trạch Dân, Lý Bằng và Chu Dung Cơ cũng nhắm vào việc đầu tư phát triển khu vực
nội địa này, mà không thành. Thế hệ nối tiếp, của Hồ Cẩm Đào, Ngô Bang Quốc và
Ôn Gia Bảo, đành ráo riết phát triển miền Đông, trưng thu và bù đắp cho miền
Tây theo kiểu "tái phân lợi tức" mà cũng không xong. Vì sự chống đối
và phá hoại của nhiều đảng bộ ở địa phương.</p><p>Nỗi
sợ thứ hai của các đấng con trời cũng xuất phát từ nguyên nhân kinh tế của nội
dung an ninh. </p><p>Thiên
triều đỏ phải ráo riết đầu tư bất kể lời lỗ để tạo ra việc làm cho dân chúng.
Hiệu suất đầu tư quá thấp, bơm ra bảy tám đồng mới nâng sản lượng được một đồng,
khiến kinh tế bị phao phí, và còn thổi lên bong bóng đầu cơ và lạm phát. Nhưng đó
là cái giá cho việc ngăn ngừa thất nghiệp để ổn định xã hội. </p><p>Kết
quả thì toàn dân toàn đảng đã sản xuất thừa và hỳ hục bán ra ngoài với giá rất
rẻ. Trung Quốc đã vượt qua Đức rồi Nhật thành đại gia xuất cảng toàn cầu là vì
nhu cầu an ninh đó. </p><p>Nhưng
toàn cầu đang bị suy trầm, và hai nguồn nhập cảng lớn nhất của Hoa lục là Âu và
Mỹ lại cứ lắc đầu và họ còn muốn xuất cảng nhiều hơn - vào Trung Quốc - để phục
hoạt kinh tế.</p><p>Đầu
máy xuất cảng mà chậm lại, đà tăng trưởng mà giảm sút, tới mức 7,5% là nhiều,
như Kế hoạch năm năm thứ 12 đã đề ta năm ngoái và Quốc hội khoá 11 đang họp vừa
mới thông báo, tình hình sẽ rất "căng". Con số tính nhẩm là tốc độ tăng
trưởng an toàn của Trung Quốc phải là 8% trở lên. Dưới mức đó là rất dễ có loạn!
</p><p>Nay
mai, khi Trung Quốc mà bán tháo lượng thép, xi măng hay hóa chất đã sản xuất
quá nhu cầu tiêu thụ nội địa thì cả thế giới sẽ hò la về "phép lạ Trung Quốc".
Cũng đáng ghét như khi Bắc Kinh bênh vực các chế độ hung đồ tại Iran và Syria.
Chi tiết lạnh mình là Thiên triều có một lượng thép dư thừa bằng sản lượng tổng
hợp của Nhật Bản và Nam Hàn, bằng cả khối Âu Châu. </p><p>Nỗi
kinh hãi thứ ba của lãnh đạo Bắc Kinh ngày nay là vùng trái độn có thể rung
chuyển....</p><p>Đây
là khu vực ngoại biên mà trung ương phải triệt để kiểm soát, từ thời Tần Thủy
Hoàng Đế đến Hán Vũ Đế cho đến Mao Trạch Đông và Hồ Cẩm Đào. </p><p>Bây
giờ, Tân Cương đã có loạn từ nhiều năm rồi. Rồi từ "khu tự trị Tây Tạng"
qua tỉnh Tứ Xuyên, dân Tây Tạng biểu tình ngày một đông hơn và bạo hơn. Tăng ni
và thanh niên Tây Tạng theo nhau tự thiêu để phản đối, từ 2009 đến nay đã có 26
vụ như vậy. Dân Mông Cổ ở Nội Mông thì nhìn qua biên giới phía Bắc với sự thèm
thuồng: Cộng Hoà Mông Cổ nay là một nước dân chủ, khắng khít hợp tác với Hoa Kỳ
và Nhật Bản, lại còn mời đức Đạt Lai Lạt Ma qua đó thuyết pháp!</p><p>Ý
thức được nhu cầu kiểm soát vùng trái độn để bảo vệ nội an, lãnh đạo Bắc Kinh đã
tung tiền đầu tư và mua chuộc các chính quyền Pakistan và Miến Điện, đã mở rộng
địa bàn hoạt động của hạm đội Thiên triều đến các quân cảng của Sri Lanka,
Pakistan, Bangladesh, và Miến Điện, v.v... </p><p>Với
kết quả là khiến Ấn Độ giật mình! Chính quyền Ấn Độ sẽ không đưa quân vượt Hy
Mã Lạp Sơn vào "giải phóng Tây Tạng", nhưng lại ngó qua Hoa Kỳ và Đông
hải, và mở vòng giao kết với Nhật Bản, nói chuyện an ninh với... Hà Nội.</p><p>Đâm
ra sợ quá hóa dại. </p><p>Lãnh
đạo Trung Quốc muốn mở rộng khái niệm "vùng trái độn" qua lãnh thổ Bắc
Việt mà chẳng ai nói gì - vì Hà Nội nín thinh cúi đầu núp sau 16 chữ vàng. Nhưng
khi Bắc Kinh coi vùng biển xanh lục, khu vực cận duyên tại Đông Nam Á - là Đông
hải của Việt Nam - thì các nước như Ấn Độ, Nhật Bản, Úc và dĩ nhiên là Hoa Kỳ đều
phải quan tâm. Và lặng lẽ phản công. </p><p>Nghĩa
là chối bỏ quyền bành trướng của Bắc Kinh. </p><p>Hoa
Kỳ xác định vai trò Á châu của mình và liên kết với Úc, nối lại quan hệ quân sự
với Phi Luật Tân và tăng cường hợp tác với Ấn Độ mà không chỉ vì hồ sơ A Phú
Hãn. Rồi Miến Điện bỗng dưng tiến ra con đường dân chủ và khu vực hạ nguồn
Mekong lại được nước Mỹ chiếu cố với nỗ lực đối thoại với Miến Điện, Thái Lan,
Lào, Miên, Việt.... </p><p>Nhìn
từ Bắc Kinh thì hình như là Thiên triều đang bị bao vây!</p><p>***</p><p>Ở
bên trong, người dân chưa giàu đã già. Lợi tức đầu người của bá tánh Trung Quốc
vẫn thuộc loại "BA Bê", chỉ ngang Belarus, Belize hay Bolivia. Bằng
con muỗi. Nhưng với bên ngoài, đây là nền kinh tế hạng nhì thế giới về sản lượng,
có đạo quân hùng mạnh của cường quốc cấp vùng. Mà cường quốc đại lục này còn muốn
trở thành cường quốc hải dương để bảo vệ luồng giao lưu buôn bán khắp năm châu
và giao kết với mọi chính quyền độc tài, từ Bắc Hàn, Việt Nam tới tạn Sudan!</p><p>Quốc
gia đói ăn và khát dầu này quả là đang làm thiên hạ sợ hãi. Nhưng ở bên trong,
hay bên trên, lãnh đạo lại có ba nỗi hãi sợ còn kinh hoàng hơn! Chúng ta nên lạnh
lùng nhìn vào ba nỗi thất kinh đó, và nghĩ đến kịch bản nước Tầu có loạn. </p><p>Khi
nước toàn có lậu, lãnh đạo Hà Nội sẽ đứng ở đâu?</p>

### Nguồn:

Viet Bao: https://vietbao.com/a184943/nhat-quoc-tam-kinh

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/