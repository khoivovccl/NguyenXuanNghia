# Khi Bọn “Tiểu Nhân” Nổi Loạn…

25/02/2017



### Nguồn:

Viet Bao: https://vietbao.com/a264541/khi-bon-tieu-nhan-noi-loan-

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/