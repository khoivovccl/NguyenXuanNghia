# Long Đinh và Long Đong

05/10/2013

Hoa Kỳ chuyển trục rồi long đinh với Châu Á...<br/><br/>Dù thiếu thời đã từng sống tại Châu Á và Hawaii, Tổng thống Barack Obama không
có duyên với Á Châu. Việc ông muốn "chuyển trục" về khu vực Đông Á có
thể là chuyện hão.<br/><br/>Hoa Kỳ đang bị thêm một vụ khủng hoảng chính trị nữa, khi một phần của bộ máy
công quyền liên bang bị tạm đóng cửa vì những mâu thuẫn không hàn gắn nổi giữa
Hạ viện Cộng Hoà với Thượng viện và Hành pháp Dân Chủ. Chuyện chính quyền đóng
cửa có thể kéo dài thêm vài tuần cho tới khi mâu thuẫn về ngân sách và chế độ bảo
dưỡng y tế (ObamaCare) sẽ lồng vào một trận đấu nữa về "định mức công
trái", mức vay mượn tối đa được Quốc hội cho phép.<br/><br/>Hậu quả bất ngờ của trò đùa nhức tim này là Hoa Kỳ tính chuyển trục về Châu Á
mà cái trục bị long!<br/><br/><div align="center"><b>* * *</b></div><br/>Về bối cảnh, Hiến pháp Hoa Kỳ trao cho Hạ viện quyền chuẩn chi mọi khoản chi của
ngân sách liên bang, sau đó chính quyền liên bang mới được quyền thanh toán.
Cũng về bối cảnh, trong mấy ngày sôi nổi, Hạ viện do đảng Cộng Hoà đã liên tiếp
bỏ phiếu để chuẩn chi mọi khoản công chi của ngân sách, trừ những hoạt động
liên hệ đến ObamaCare. Những ai muốn biết sự thật thay vì mắc lừa thủ thuật
chính trị hoặc nghe lời vu cáo, có khi xuất phát từ báo chí mắc chứng Obamê,
thì có thể tìm đọc trong Congressional Record (<a href="/siteadmin/D_CatID-3_Table-NewsArticle_LanguageID-2_SiteID-2/www.gpo.gov">www.gpo.gov</a>).<br/><br/>Thượng viện và Hành pháp trong tay đảng Dân Chủ thì coi rằng việc cải tạo y tế
đã thành luật từ ba năm nay và một phần quan trọng bắt đầu đi vào áp dụng, khá
lụp chụp, từ hôm mùng một nên đã phản bác mọi kết quả biểu quyết tại Hạ viện. Họ
nhất quyết không nhượng bộ, mà đảng Cộng Hoà theo truyền thống ngây ngô cố chấp
lại không giải thích được cho rõ. Rồi đôi bên đổ lỗi cho nhau là đã đóng cửa bộ
máy công quyền liên bang. Thật ra, chỉ một số hoạt động không được coi là quan
yếu mới bị tạm ngưng mà thôi.<br/><br/>Đây là một chương nối dài của trận đánh về ngân sách đã khởi sự từ năm 2011 với
vụ trái phiếu Mỹ bị hạ điểm tín nhiệm vào Tháng Tám, kéo qua hai đòn giảm chi gọi
là "vực thẳm ngân sách" fiscal cliff vào năm 2012 và "cầm cố
công chi" sequestration vào đầu năm nay.<br/><br/>Trở lại nguồn gốc của trận đánh thì từ quá lâu rồi, chính quyền liên bang Hoa Kỳ
bị bội chi ngân sách liên tục nên cứ đi vay, nhưng chỉ có thể vay trong giới hạn
của Quốc hội. Vì khoảng hai tuần nữa (ngày 17 này, theo một cách tính của Bộ
Ngân khố) thì Mỹ sẽ đụng vào giới hạn đó nên phải được lưỡng viện Quốc hội cho
nâng thêm trần nợ. Nếu không, chính quyền chẳng thể tôn trọng những cam kết với
các chủ nợ là giới đầu tư trái phiếu trên toàn cầu.<br/><br/>Trường hợp đó được gọi là "default", hay "vi ước", một bước
trước khi rơi vào tình trạng vỡ nợ (insolvency) rồi phá sản (bankcruptcy). Nước
Mỹ giàu có không thể vỡ nợ, nhưng khi vi phạm cam kết thì mức tín nhiệm về tài
chánh sụt giảm sẽ khiến phân lời trái phiếu gia tăng, và lãi suất tăng thì gây
bất lợi lớn cho kinh tế. Trong hai ngày liền, Bộ Ngân khố (hay Tài chánh) Mỹ đã
kín đáo rồi công khai cho biết là nếu không sớm khai thông những ách tắc chính
trị hiện nay, Hoa Kỳ sẽ bị một vụ khủng hoảng tài chánh còn nghiêm trọng hơn vụ
2008.<br/><br/>Nghe thấy vậy thì ai cũng sợ!<br/><br/>Bây giờ ta mới nhìn ra bên ngoài....<br/><br/><div align="center"><b>* * *</b></div><br/>Hôm Thứ Tư mùng hai, Phủ Tổng thống cho biết là vì lý do vận trù hay "hậu
cần" – logistic, khi thiếu nhân viên bảo vệ tổng thống do bộ máy công quyền
bị đóng cửa – Tổng thống Obama sẽ không thể thăm viếng Malaysia và Philippines
trong hai ngày 11-12 tới đây như đã dự trù. Chiều Thứ Năm, tòa Bạch Cung tăng
phần kịch tính mà thông báo là Tổng thống sẽ hủy luôn cả chuyến Á du để ở nhà
khai thông ách tắc. Đại diện cho ông sẽ là Ngoại trưởng John Kerry, Tổng trưởng
Thương mại Penny Pritzker và Đặc sứ Thương mại Hoa Kỳ là Michael Froman.<br/><br/>Được trù tính từ lâu, chuyến Á du của Tổng thống Mỹ từ mùng bảy đến 12 để ông
Obama dự Thượng đỉnh APEC của Diễn đàn Hợp tác Kinh tế Á châu Thái bình dương tại
Bali của Indonesia và Thượng đỉnh ASEAN của Hiệp hội 10 Quốc gia Đông Nam Á và
Thượng đỉnh Đông Á tại tiểu vương quốc Brunei rồi sẽ chính thức thăm viếng Mã
Lai Á và Phi Luật Tân. Sau khi bỏ rơi chuyến Phi-Mã, Hoa Kỳ cũng khỏi dự các
thượng đỉnh APEC và ASEAN....<br/><br/>Với giới lãnh đạo Á Châu thì đây là điều đáng tiếc sau nhiều vụ lỡ hẹn khác, lại
một chuyện... vi ước về ngoại giao.<br/><br/>Tháng Ba năm 2010, Tổng thống Mỹ đã dời lại rồi hủy luôn việc thăm viếng
Indonesia và Úc vì phải ở nhà vận động cho đạo luật cải tạo y tế nên hẹn qua
Tháng Sáu. Rồi đến hẹn lại xuống! Hai chuyến thăm viếng chính thức này cũng lại
bị hủy vào Tháng Sáu vì tai nạn dầu khí của tổ hợp BP trong Vịnh Mễ Tây Cơ.<br/><br/>Từ mấy chục năm nay, tình trạng bội chi lưu cữu và mâu thuẫn quan điểm về ngân
sách từng xảy ra nhiều lần khiến một phần không quan trọng của chính quyền liên
bang bị tạm thời đóng cửa. Người ta thường nói đến 26 ngày đình đọng cuối năm
1995 và đầu năm 1996 khi có đụng độ về ngân sách giữa Hành pháp Dân Chủ (Tổng
thống Bill Clinton) và Hạ viện Cộng Hoà (Dân biểu Newt Gringrich). Thật ra, trước
đó đã từng có nhiều lần tương tự dù ngắn hơn, giữa Hành pháp Cộng Hoà thời
Ronald Reagan và Quốc hội Dân Chủ (Dân biểu "Tipp" O'Neill), vào các
năm 1981, 1982, 1984, 1986 và 1987.<br/><br/>Nhưng chưa khi nào mà một Tổng thống Mỹ lại nhiều lần lỗi hẹn với các nguyên thủ
quốc gia như Obama trong khi Hoa Kỳ đang lúng túng giải quyết hồ sơ Trung Đông,
chuyện Syria và Iran, trước sự thất vọng của các đồng minh như Israel, Saudi
Arabia, Egypt và Turkey. Lần trước vào năm 1995, Tổng thống Bill Clinton cũng
đã phải bỏ Thượng đỉnh APEC vì một vụ shutdown ở nhà, nhưng ông kịp hàn gắn vụ
này khi thăm viếng Nhật Bản và Nam Hàn năm sau.<br/><br/>Với Á Châu, tình hình còn tệ hơn vậy. Từ gần bốn năm nay, Chính quyền Obama rầm
rộ thông báo việc chuyển trục về Đông Á sau khi Mỹ rút chân khỏi vũng lầy Trung
Đông (Iraq) và Trung Á (Afghanistan). Chuyện triệt thoái chưa xong thì bây giờ
bên trong lại có loạn vì phản ứng của đảng Cộng Hoà, được nhiều người trong phe
Dân Chủ gọi là khủng bố Hồi giáo Jihadsist.<br/><br/>Đấy là lúc Tổng thống Iran cho tiết lộ rằng phía Hoa Kỳ đã năm lấn bắn tiếng muốn
đàm phán, nhưng đều bị Tehran từ chối.... Người ta còn biết thêm là nhân khóa họp
của Đại hội đồng Liên Hiệp Quốc vừa qua ở New York, Chính quyền Obama muốn Tổng
thống Hoa Kỳ và Iran gặp nhau, nhưng chuyện không thành vì Tổng thống Hassan
Rouhani bận gặp báo chí nên sau cùng Tổng thống Obama đành phải gọi điện thoại
nói chuyện vài câu khi Rouhani trở về Tehran.<br/><br/>Đâm ra Tổng thống Mỹ có thể nằn nì nói chuyện với đối thủ Iran mà nhất quyết
không nhượng bộ đối lập Cộng Hoà ở nhà!<br/><br/><div align="center"><b>* * *</b></div><br/>Trong vụ này, nước Mỹ hụt mất những gì tại Châu Á?<br/><br/>Theo nghị trình, Tổng thống Mỹ phải tới Manilla thảo luận về hợp tác quân sự với
lãnh đạo Philippines trước sự theo dõi tìm hiểu của các nước trong Hiệp hội
ASEAN vì liên hệ đến an ninh Đông Nam Á trước sức ép của Trung Quốc. Tại
Malaysia, Tổng thống Mỹ cũng có cơ hội đẩy mạnh việc đàm phán để sớm hoàn thành
Hiệp ước Đối tác Xuyên Thái bình dương TPP bị ách tắc vì sự chống đối của các tập
đoàn quốc doanh Mã Lai Á. Với Kuala Lumpur, Tổng thống Mỹ còn có nhu cầu xây dựng
một quan điểm thống nhất với cả khối ASEAN về Quy tắc Hành xử tại vùng biển
Đông Nam Á để gây áp lực với Bắc Kinh.<br/><br/>Nhưng Obama lại vắng mặt và nhường sân chơi Malaysia cho Chủ tịch Tập Cận Bình
của Bắc Kinh. Lãnh đạo Trung Quốc có ba ngày viếng thăm chính thức Malaysia, từ
mùng ba đến mùng năm, sau khi đã tới Indosenia. Ông đem theo nhiều dự án hấp dẫn
và lập trường kiên định của mình về Đông hải, để bẻ từng chiếc trong bó đũa
ASEAN.<br/><br/>Sau khi hủy chuyến công du Phi-Mã, Tổng thống Mỹ còn quay lưng với Đông Á khi bỏ
luôn các thượng đỉnh, là nơi mà Tập Cận Bình và Tổng thống Vladimir Putin bình
thản gặp gỡ và tranh thủ các nước Đông Á trước sự tường thuật của truyền thông
quốc tế.<br/><br/>Thật ra, tình trạng lỡ hẹn đáng tiếc này còn cho thấy một sự thật khác về mức
ưu tiên trong tư duy và đối sách của Barack Obama.<br/><br/>Với tài hùng biện, ông có thể ăn nói nước đôi, đỏ đen trái phải gì thì mình
cũng đúng. Nhưng căn bản thì ban tham mưu về an ninh và đối ngoại của ông thiếu
người am hiểu về Châu Á, mà lại còn tập trung vào các hồ sơ khác. Và trong bài
diễn văn Tổng thống Mỹ đọc trước Đại hội đồng Liên hiệp Quốc, Á Châu lẫy lừng vắng
mặt. Không đáng kể trong mối quan tâm của Obama.<br/><br/>Trước sự bành trướng kiên trì của Trung Quốc, các nước Đông Nam Á đành trông
vào hai cường quốc trong khu vực là Nhật và Úc. Và chờ một Tổng thống khác của
Hoa Kỳ.<br/><br/>Nhìn lại như vậy thì chuyện một phụ nữ nổi điên tông xe vào Phủ Đầu Rồng rồi
phóng bạt mạng qua Quốc hội làm náo loạn thủ đô Mỹ để bị bắn hạ vào chiều Thứ
Năm vửa qua chưa phải là chuyện điên nhất của nước Mỹ. Thảm.

### Nguồn:

Viet Bao: https://vietbao.com/a211222/long-dinh-va-long-dong

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/