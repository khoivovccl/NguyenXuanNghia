# Bất Ổn Tài Chính Gây Khủng Hoảng Kinh Tế

05/02/2015



### Nguồn:

Viet Bao: https://vietbao.com/a233272/bat-on-tai-chinh-gay-khung-hoang-kinh-te

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/