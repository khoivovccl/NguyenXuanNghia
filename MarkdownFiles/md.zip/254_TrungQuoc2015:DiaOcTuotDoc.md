# Trung Quốc 2015: Địa Ốc Tuột Dốc

31/12/2014



### Nguồn:

Viet Bao: https://vietbao.com/a231703/trung-quoc-2015-dia-oc-tuot-doc

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/