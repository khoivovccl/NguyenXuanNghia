# Âu Châu Vào Bước Ngoặt

03/12/2011

<p>Âu
Châu Vào Bước Ngoặt</p><p>Nguyễn
Xuân Nghĩa</p><p></p><p>Con
đường khổ ải của Âu Châu....</p><p>Vài
tuần tới, ngày mùng chín, lãnh đạo các nước Âu Châu sẽ lấy một quyết định sinh
tử cho cả đại lục hơn 500 triệu dân của 27 quốc gia, trong đó có 17 nước đã
dùng chung một đồng Euro....</p><p>Tiếp
theo Tổng thống Nicolas Sarkozy vào tháng 10, cuối tháng 11, Ngoại trưởng Pháp
cũng vừa nhắc lại lời cảnh báo có thể làm thiên hạ rùng mình: nếu không cứu được
đồng Euro, chiến tranh có thể bùng nổ tại Âu Châu!</p><p>Trên
cột báo này, từ nhiều năm trước rồi, người viết vẫn tỏ vẻ hoài nghi khả năng tồn
tại của việc thống nhất Âu Châu - Liên hiệp Âu châu EU như người ta vẫn gọi từ
năm 1993 - lẫn kế hoạch hợp nhất tiền tệ của khối Euro. </p><p>Lý
do đơn giản của sự phán đoán này là sự thống nhất về kinh tế hay tiền tệ đòi hỏi
một quy cách hành xử thống nhất về kinh tế, ngân sách và tài chánh của các
thành viên. Nghĩa là một sự thống nhất về chính trị, với khả năng cưỡng hành của
một cơ chế lãnh đạo siêu quốc gia. Chuyện đúng sai của lý luận này không quan
trọng, và chẳng ai có thể biết trước hoặc đoán đúng mọi chuyện - nhất là cho đa
số độc giả đang sinh sống tại Hoa Kỳ và coi vấn đề Âu châu là xa xôi.</p><p>Tuy
nhiên, tuần này, các nước Âu Châu đang đứng trước sự chọn lựa đó, tiến tới thống
nhất hoặc lui về sự tan rã, với hậu quả có thể là bất ổn toàn cầu về kinh tế và
xung đột Âu châu về chính trị, thậm chí quân sự như lãnh đạo Pháp đã báo động.</p><p>Vì
vậy, bài viết này sẽ... lùi một bước mà trình bày lại toàn cảnh của các quyết định
và xin cáo lỗi trước về những chi tiết quá chuyên môn mà phải giản lược hóa.</p><p>***</p><p>Sau
nhiều năm lạc quan duy ý chí, các nước Âu châu đang đứng trước hai ngả chọn lựa.
Một là "xóa nợ" hai là "nuốt nợ", cả hai ngả đều như liều
thuốc đắng. </p><p>Xóa
nợ là đồng loạt phủ nhận nghĩa vụ thanh toán trái phiếu đã lỡ phát hành, với
nhiều chủ nợ công và tư sẽ bị thiệt hại, như cái giá cần thiết để duy trì hiện
trạng và nhân đó mà tìm cách ngăn ngừa những tái diễn sau này. Nuốt nợ là lập
ra một cơ chế chính trị có thẩm quyền liên bang để kiểm soát ngân sách quốc gia
của từng nước và thống nhất sự tài trợ của từng chính quyền. </p><p>Hai
quyết định ấy đều đòi hỏi việc tu chính Hiến pháp Âu châu của 27 thành viên, hoặc
ít nhất việc sửa sai lại quy cách hành xử kinh tế của khối Euro gồm có 17 thành
viên.</p><p>Nếu
các nước đạt nổi thỏa thuận về một sự thống nhất minh bạch, khả thi và mạch lạc
thuần nhất về kỷ luật ngân sách và về quy cách tài trợ công chi trong từng nước,
Âu Châu có hy vọng tiến dần đến ổn định - và đẩy lui nguy cơ suy trầm hoặc thậm
chí quy thoái toàn cầu vào năm tới.</p><p>Ngược
lại, nếu các nước không thể thống nhất lập trường về cả kỷ luật ngân sách lẫn
quy cách công chi, tình trạng vỡ nợ của các ngân hàng và nhiều quốc gia sẽ tiếp
tục với đà gia tốc, ngày một mạnh hơn và sâu rộng hơn. Khi ấy giấc mơ thống nhất
Âu Châu được ấp ủ từ sau Thế chiến II sẽ biến thành ác mộng. </p><p>Và
kịch bản chinh chiến truyền thống của lục địa này sẽ là thảm kịch cho cả thế giới.</p><p>Khi
theo dõi tin tức Âu châu người ta cần nhớ thực tế là nguy cơ vỡ nợ của các
chính quyền và ngân hàng Âu châu. Nguy cơ ấy khiến các chính quyền Hy Lạp và Ý
theo nhau sụp đổ và tai họa có thể lan qua Tây Ban Nha, Bỉ, Pháp và Hoa Kỳ. Từ
Tây Ban Nha, toàn khối Mỹ châu La tinh cũng sẽ lãnh vạ.</p><p>Nhân
đây, xin nhắc đến sự lạc quan tếu của thị trường chứng khoán Mỹ và toàn cầu vào
Thứ Tư 30 vừa qua vì biện pháp can thiệp có phối hợp của các ngân hàng trung ương
Mỹ, Âu, Nhật, Anh và Canada, v.v... để cấp cứu các ngân hàng Âu châu khỏi bị
ách tắc tín dụng. Quyết định ấy, do Ngân hàng Trung ương Mỹ đề xướng, chỉ cho
thấy tư thế rất mạnh của đồng Mỹ kim và nước Mỹ, trước sự suy bại của Euro. Nhưng
đây là một đề tài quá chuyên môn khác, xin dành cho một kỳ khác.</p><p>Khi
mọi người đều nói, hoặc biết, rằng Âu châu có nguy cơ vỡ nợ, thị trường luôn
luôn chờ đợi tin xấu và xác nhận giả thuyết bi quan nhất, khiến cho dự đoán rất
dễ trở thành hiện thực.</p><p>Trong
hoàn cảnh bấp bênh đó, kéo dài từ năm 2009 đến nay, người ta còn châm thêm một
yếu tố bất ổn khác: số phận hay sự lành lặn của đồng Euro. </p><p>Lãnh
đạo Đức và Pháp, Thủ tướng Angela Merkel và Tổng thống Nicolas Sarkozy đều nói
thẳng đến điều tối kỵ trước đây, rằng ra khỏi khối Euro không là điều bất khả.
Nôm na là có quốc gia sẽ rút khỏi khối Euro. Từ Tháng Ba vừa qua, Tổng trưởng
Tài chánh Đức, một lãnh tụ thế giá trong liên minh cầm quyền của bà Merkel, còn
phát biểu thẳng thừng rằng có nhiều nước không đáng tham dự khối tiền tệ thống
nhất vì không tôn trọng quy củ chung. </p><p>Trong
khung cảnh phập phồng lo sợ chuyện Âu Châu vỡ nợ, sự sứt mẻ của đồng Euro lại
càng gây thêm bất ổn. Người viết đã gọi đồng Euro là đồng sứt trong tinh thần đó.</p><p>***</p><p>Khi
ấy, người ta trở lại với thực tế của tín dụng và tiền tệ: sự tin tưởng, tín nhiệm,
vào đồng bạc, nói cho văn hoa là một "tín tệ". </p><p>Mọi
ngân hàng đều trước tiên là khách nợ - "con nợ" là một cách gọi khác.
</p><p>Ngân
hàng thương mại là khách nợ của các trương chủ ký thác. Các trương chủ là chủ nợ
của ngân hàng. Nếu họ mất niềm tin và xếp hàng đòi nợ, nghĩa là rút tiền ký
thác, thì ngân hàng có thể sụp đổ. Ngân hàng trung ương cũng vậy, là con nợ của
những người sử dụng đồng tiền hay cầm trái phiếu trong tay. Họ mà không tin vào
giá trị của đồng bạc hay tờ giấy nợ mà bán tháo để gìn giữ tài sản dưới dạng
khác thì ngân hàng trung ương bị khốn đốn.</p><p>Trong
hoàn cảnh đó, nếu một hay nhiều quốc gia lại có thể ra khỏi khối Euro - tự ý
sau khi trưng cầu dân ý như Hy Lạp đã dự tính, hoặc bị yêu cầu bước ra trong năm
bảy năm nhất định - giá trị của đồng bạc này sẽ là gì? </p><p>Một
triệu đồng Euro ký thác trong một ngân hàng Hy Lạp hoặc một xấp bạc Euro trong
tay người dân khi ấy có còn giá trị gì không? Nếu lại là ngân hàng Ý hay Pháp,
hoặc người dân Đức, hậu quả sẽ ra sao? Suy từ vài thí dụ đó thì dù chẳng là
chuyên gia kinh tế, mọi người đều đoán ra giả thuyết có xác suất cao nhất:
thiên hạ rút tiền ở mọi nơi và ký thác vào ngân hàng Đức. Hàng loạt ngân hàng
hay quốc gia không chỉ vỡ nợ mà phá sản!</p><p>Những
tin tức dồn dập từ nhiều tháng nay đang dẫn tới kịch bản kinh hoàng đó. Hậu quả
là nhiều người sẽ ghét Đức và càng nghi ngờ giải pháp cấp cứu do lãnh đạo Đức đề
nghị!</p><p>Bây
giờ, làm sao ngăn ngừa và đẩy lui tâm lý hốt hoảng đó, hoặc làm sao khôi phục
niềm tin? </p><p>Mà
tin vào cái gì? </p><p>***</p><p>Trước
hết, người ta có thể trấn an dư luận rằng dù các ngân hàng hay chính quyền có
thể bị vỡ nợ, Âu Châu vẫn có "cơ chế tài trợ sau cùng", một cái lưới đủ
bền chắc và an toàn để chống đỡ toàn bộ kiến trúc bị rung rinh. </p><p>Ngân
hàng trung ương của Âu Châu hoặc một số quốc gia không nằm trong khối Euro có
thể là "nhà tài trợ sau cùng" nếu các ngân hàng theo nhau sụp đổ. Các
thành viên khác có đồng ý cho Ngân hàng Trung ương ECB chức năng đó không, và với
tiền ở đâu? Đấy là một cuộc tranh luận kỹ thuật không chỉ có kích thước tài
chánh mà còn có nội dung chính trị và đã bùng nổ từ nhiều tuần nay khi người ta
thấy khả năng ứng phó rất giới hạn - vì thiếu tiền - của Quỹ Bình Ổn Tài chánh
Âu Châu EFSF. Trong tuần này, ta sẽ thấy định chế ECB sẽ là đề mục thời sự nóng
nhất. </p><p>Yếu
tố quyết định ở đây là chính trị.</p><p>Đằng
sau ECB còn có một tấm lưới khác, Quỹ Tiền tệ Quốc tế IMF. Nhưng định chế này
có gần 200 thành viên và một đại gia có ảnh hưởng đến gần 17% của phần vốn và
quyền quyết định là Hoa Kỳ. Các nước bên ngoài Âu Châu có chấp nhận cho IMF hút
sạch vốn liếng nước nôi để chữa lửa Âu Châu không? Mà IMF không có thói quen cấp
cứu vô điều kiện. Đòi hỏi chấn chỉnh của IMF là loại điều kiện mà nhiều nước đang
phát triển đã coi như thuốc đắng có thể dẫn tới đột tử về chính trị. </p><p>Yếu
tố quyết định ở đây cũng vẫn là chính trị.</p><p>Ngoài
cái lưới ngân hàng trung ương, cơ chế thứ nhì có thể trấn an thị trường là các
chính quyền. </p><p>Nếu
ngân hàng có chức năng tín dụng và tiền tệ, chính quyền có chức năng ngân sách
(thuế vụ và công chi thu). Khi thị trường đang hốt hoảng như hiện nay, người ta
có thể bớt sợ nếu có nhà tài trợ sau cùng là ngân hàng trung ương và ngoài ngân
hàng trung ương thì còn một nhà tài trợ sau cùng nữa là chính quyền. Mà chính
quyền nào?</p><p>Một
chính quyền siêu quốc gia, có đặc tính liên bang trên các nước Âu châu khi ấy
phải chấp nhận "quy chế tiểu bang" của mình, ít ra về kinh tế. Cơ chế
siêu quốc đó chưa có. Đức và Pháp đang vận động các nước tiến tới giải pháp
này. Đề nghị ấy hàm nghĩa là một cơ chế còn lớn mạnh và có thẩm quyền hơn những
cơ quan hiện hữu của Liên Âu để kiểm soát việc công chi thu của các hội viên. </p><p>Và
cụ thể hơn nữa, các nước phải cho cơ chế này một tổ chức kỹ thuật thống nhất để
bảo đảm là mọi hội viên đều chấp hành quy luật liên bang và một thể thức hành xử
linh động để kịp thời can thiệp và cấp cứu khi hữu sự. Yếu tố ở đây cũng vẫn là
chính trị! Nhất là chính trị.</p><p>Và
đòi hỏi việc tu chính lại Hiến pháp Âu châu, hoặc các Thỏa ước Maastricht,
Lisbon, lẫn soạn thảo ra một sơ đồ tổ chức và điều lệ kiểm soát, can thiệp,
v.v.... Chúng ta chưa nói đến cơ chế ngoại giao hay quân sự thống nhất của Âu
Châu mà chỉ tạm nghĩ đến dàn cảnh sát thuế vụ và thanh tra ngân hàng thôi!</p><p>Nghĩa
là người ta cần viết lại tờ giấy khai sinh của Âu Châu. </p><p>Trong
nội một tuần thì dù có là đại gia Âu Châu như Vua Charlemagne hay Đại đế
Napoléon, Otto Bismarck hoặc Winston Churchill và Charles de Gaulle, v.v...
cũng khó có thể làm được việc đó. Tối đa thì lãnh đạo Âu châu chỉ có thể vẽ ra
lộ trình cải cách, một khung cửa hẹp duy nhất còn lại. Trước khi mọi sự đều
tanh bành. </p><p>Chúng
ta sẽ theo dõi tin tức về lộ trình Âu châu qua khung cửa hẹp đó.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a180558/au-chau-vao-buoc-ngoat

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/