# Ra Khỏi Bóng Rợp Kinh Tế Của Trung Quốc

29/05/2014



### Nguồn:

Viet Bao: https://vietbao.com/a222030/ra-khoi-bong-rop-kinh-te-cua-trung-quoc

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/