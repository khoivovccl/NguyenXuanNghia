# Putin & Ukraine - Các Chuyển Động Đáng Sợ

21/02/2014

Vì Sao Khủng Hoảng Tại Ukraine Lại Làm Putin Bủn Rủn?<br/><br/>Tình hình tại Cộng hòa Ukraine đã bước qua một khúc quanh mới, có thể là điểm
lật vì dẫn tới nhiều thay đổi lớn, với hậu quả lan rộng vào tận Liên bang
Nga...<br/><br/>Có ba yếu tố mới rất đáng chú ý ở đây, nếu ta để ý tới địa dư và lịch sử.<br/><br/>Sau nhiều tuần lễ biến động tập trung tại thủ đô Kiev, phong trào đấu tranh
chống việc Chính quyền của Tổng thống Viktor Yanukovich ngả theo Liên bang Nga
đã lan tới nhiều nơi khác, ở miền Tây. Dân chúng đã biểu tình bạo động tại năm
thành phố và khu vực hành chánh ở phía Tây là (từ Tây qua Đông) Uzhhorod -
thành phố giáp giới với nước Hung và Slovakia - rồi Liviv, Ivano-Frankivsk,
Ternopil và Khmetnytskyi.<br/><br/>Từ Kiev đến các trung tâm này, từ hôm Thứ Tư 19, dân biểu tình chiếm nhiều công
thự, thậm chí bắt giữ cảnh sát và trưng thu được nhiều võ khí cá nhân. Mấy chục
người đã thiệt mạng trong các cuộc đụng độ tại quảng trường Độc Lập (Maidan, có
tên thật là "Quảng trường Âu châu") của thủ đô và ở cả Khmetnytskyi.
Tình hình tại chỗ thay đổi hàng giờ bất chấp thỏa thuận hưu chiến giữa Tổng
thống Yanukovich với các lãnh tụ đối lập.<br/><br/>Bài này được viết trong khung cảnh đột biến nóng hổi ấy.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Yếu tố đáng chú ý trước nhất là việc dân biểu tình tại Lviv đã ra tuyên ngôn
độc lập. Họ muốn Lviv khỏi ra xứ Ukraine.<br/><br/>Đáng chú ý vì Lviv là thành phố Âu Châu nhất của Cộng hoà Ukraine mà cũng là
nơi xuất phát tinh thần quốc gia của dân Ukraine. Chuyện hơi lạ mà ít được
truyền thông Mỹ nhìn ra vì mắc tật dốt nát kinh niên về lịch sử thế giới.<br/><br/>Từ thế kỷ 16 đến 18, khu vực Lviv này có tên là Lwow, thuộc Cộng đồng Thịnh
vượng Ba Lan và Lithuania (Polish-Lithuanian Commonwealth) cho tới khi bị Đế
quốc Habsburg của Áo cai trị và cải danh ra Lemberg khi Cộng đồng Thịnh vượng
kia bị xẻ ra nhiều mảnh. Sau Thế chiến I (1914-1918), Lemberg trở về với Ba Lan
nhưng rồi bị Liên bang Xô viết thôn tính và được đổi tên là Lvov trong lãnh thổ
Ukraine. Khi Liên Xô tan rã năm 1991, Cộng hòa Ukraine tuyên bố độc lập cũng từ
những vận động phát sinh từ Lvov, khi ấy được đổi tên thành Liviv.<br/><br/>Trải bốn thế kỷ, qua các thời kỳ có tên là Lwow, Lemberg, Lvov rồi Liviv, khu
vực này có một định mệnh riêng.<br/><br/>Lviv là trung tâm văn hóa, nghệ thuật, kiến trúc, ngôn ngữ, thi ca và nhất là ý
thức quốc gia của dân Ukraine. Phong trào đấu tranh của dân Ukraine để biệt lập
với Đế quốc Nga và Xô viết xuất phát từ đây, không phải từ miền Đông và khu vực
Donbass, hậu cứ của Viktor Yanukovich thân Nga.<br/><br/>Người dân nơi đây nói tiếng Ukraine và từ chối tiếng Nga. Họ hãnh diện với xuất
xứ Âu Châu và dân Âu Châu gọi thành phố này là "Tiểu Paris của
Ukraine" (Little Paris!). Danh nhân và anh hùng của họ là văn hào và nhà
thơ Taras Shevchenko, người đã phát huy ngôn ngữ và tinh thần dân tộc của
Ukraine. Hoàng Diệu và Phan Khôi hay Nguyễn Du và Phan Bội Châu dồn làm một!<br/><br/>Vì những yếu tố sâu xa đó, Lviv ít bị ảnh hưởng của Nga, thậm chí rất kỵ dân
Nga La Tư Slav, và thiên về Âu Châu cùng lý tưởng dân chủ sau khi Liên Xô tan
rã.<br/><br/>Bây giờ, phong trào chống đối tại Lviv đòi ly khai để trở thành một nước độc
lập và không còn lệ thuộc gì vào chế độ Yanukovich thân Nga. Khi đó, người dân
Ukraine ở nơi khác sẽ tính sao? Ngả về Tây hay về Đông?<br/><br/>Và lãnh tụ Vladimir Putin của Nga sẽ tính sao khi các nước Âu Châu như Ba Lan,
Áo, và cả Liên hiệp Âu châu cùng Hoa Kỳ đều ngỏ ý can gián Yanukovich - để can
thiệp?<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Yếu tố mới thứ hai cũng đáng chú ý là trong Chính quyền Yanukovich đã có nhiều
dấu hiệu rạn nứt.<br/><br/>Hôm Thứ Tư 19, Tổng thống Yanukovich cách chức Tổng Tư lệnh và Tham mưu trưởng
của Tướng Volodymyr Zaman và chỉ định người thay thế là Tư lệnh Hải quân, Đế
đốc Yuriy Ilyin. Quyết định ấy cho thấy Yanikovich đang tính tới một giải pháp
khác: cho quân đội đi dẹp loạn.<br/><br/>Cho tới nay, chế độ mới chỉ sử dụng công an và cảnh sát với kết quả tạm gọi là
"bất phân thắng bại".<br/><br/>Cảnh sát kiểm soát được trung tâm Maidan tại thủ đô mà chưa dẹp nổi các khu vực
biến động. Yanukovich có thể trông cậy vào phản ứng bạo động của những thành
phần quá khích nhất để tranh thủ hậu thuẫn của quần chúng và cô lập đám biểu
tình. Nhưng bạo động lại lan khỏi thủ đô qua các tỉnh miền Tây. Mà trong số
này, Lviv thì không đòi lật đổ hoặc thay thế chế độ thân Nga ở Kiev. Họ muốn ly
khai và lập ra một nước mới, một nước khác!<br/><br/>Giải pháp của Yanukovich có thể là đưa quân đội ra khỏi trại lính để vãn hồi
trật tự.<br/><br/>Nhưng việc ông ta thay thế người cầm đầu quân đội cho thấy là lực lượng này
thiếu thống nhất. Nhiều tướng lãnh không muốn ủng hộ quyết định ấy. Sau những
do dự, thậm chí hòa giải của nhiều đơn vị an ninh và cảnh sát tới độ giao nộp
vũ khí cho dân biểu tình, Yanukovich đã nói tới nhu cầu "chống nổi
dậy" và đề cao sức mạnh của quân đội Ukraine.<br/><br/>Chưa chắc là quân đội đã muốn vậy. Ba chân kiềng bảo vệ chế độ là cảnh sát, an
ninh và quân đội, đều có vẻ lung lay. Và không cùng nằm trên một mặt phẳng.<br/><br/>Đấy là mối lo của kẻ xa lửa mà vẫn rát mặt là Vladimir Putin.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Tuần qua, Tổng thống Nga đã nêu một sáng kiến có tính chất hòa giải cho
Ukraine, đó là thiết lập thế chế liên bang. Sáng kiến đó không gây tiếng vang
mà bị chìm trong tiếng súng.<br/><br/>Là người có trí nhớ, Putin không quên được những gì đã xảy ra tại Ukraine 10
năm về trước và nghĩ tới.... Moscow.<br/><br/>Năm 2004, dân Ukraine cũng đã biểu tình tại quảng trường Maidan của Kiev để
phản đối cuộc bầu cử mà họ cho là có gian lận. Kết quả là Viktor Yanukovich bị
lật đổ, cuộc Cách mạng Da cam đưa lên một Chính quyền thân Tây phương tại Kiev,
với hai lãnh tụ phong trào chống đối là Viktor Yushchenko lên làm Tổng thống và
bà Yulia Timoshenko làm Thủ tướng.<br/><br/>Vào thời đó, các cuộc cách mạng muôn màu dân chủ tại Georgia, Kyrgyzstan và
Serbia đã gây khó chịu cho Putin. Nhưng Cách mạng Da cam tại Kiev mới gây lo
sợ! Lại xin một bài học chớp nhoáng khác về lịch sử.<br/><br/>Đã nói về Lviv với sức hút của Âu châu thì phải nói về Kiev. Ukraine là vùng
đất sinh sống của dân Nga La Tư Slav, với đa số vẫn nói tiếng Nga hơn là tiếng
Ukraine (vì vậy chuyện Lviv mới đáng chú ý). Tại Ukraine, Kiev là một trung tâm
văn hóa và chính trị của Nga, một bậc thềm cho tiến trình Tây phương hóa và
hiện đại hóa nước Nga từ Thế kỷ 19.<br/><br/>Với một lãnh tụ có tinh thần đề cao Đế quốc Nga muôn thuở như Putin thì Ukraine
chỉ là một thành phần, một tỉnh, một địa phận của nước Nga bát ngát. Và Kiev là
nơi tỏa sáng tinh hoa Nga La Tư về hướng Tây.<br/><br/>Thời ấy, 10 năm về trước, Putin đang củng cố lại chế độ chính trị Nga, với khái
niệm quái lạ là nền "dân chủ có chủ quyền", để dưới nhãn dân chủ tập
trung lại quyền lực vào khu vực trung ương, vào Moscow và điện Kremlin. Tức là
vào trong bàn tay sắt của mình, dù có bọc nhung thì vẫn là bàn tay sắt.<br/><br/>Vậy mà, thời ấy Kiev lại có loạn và phong trào dân chủ dẫn tới phong trào Âu
châu hóa, Tây phương hóa. Dưới con mắt của Putin, những gì xảy ra tại Kiev đều
có thể xảy ra tại Moscow!<br/><br/>Tại Moscow, Putin đã xây dựng được chế độ tập quyền rất kiên cố và dẹp tan mọi
mầm chống đối của trí thức hay nghệ sĩ. Dưới tuyết lạnh căm căm thì mọi tay
chống đối đều phải co vòi. Hay vào tù. Những kẻ khác thì có thể mua chuộc bằng
quyền lợi kinh tế.<br/><br/>Nhưng dưới tuyết lạnh căm căm, dân chúng Kiev vẫn biểu tình mà Yanukovich lại
dẹp không nổi! Gói quà mua chuộc trị giá 15 tỷ đô la được Putin hứa tặng chế độ
chư hầu tại Kiev cũng chẳng có vẻ gì là công hiệu!<br/><br/>Ngày nay, dân chúng Moscow theo dõi sự biến tại Ukraie với nhiều cảm nghĩ linh
tinh! Vừa khâm phục dân chúng ở thủ đô Kiev vừa hãi sợ kịch bản độc lập của
Liviv.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Ngẫm lại thì phong trào cách mạng dân quyền và dân chủ tại Âu Châu vào thế kỷ
19 đã khiến Vladimir Illich Lenin hãi sợ mà dựng lên lý luận về Đế quốc. Chủ
yếu là để gây phân hóa tại Âu Châu và củng cố chế độ cộng sản của mình ở tại
Nga.<br/><br/>Lần này, hình như lịch sử tại tái diễn ngược, và ở ngay Ukraine.<br/><br/>Đã từng chứng kiến sự sụp đổ của chế độ Cộng sản tại Nga vào một mùa Đông 1991,
Putin thấy rét căm căm mà không vì tuyết lạnh tại Thế vận Sochi....<br/><br/>Đúng là lời nguyền rủa của Thế vận hội!

### Nguồn:

Viet Bao: https://vietbao.com/a217632/putin-ukraine-cac-chuyen-dong-dang-so

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/