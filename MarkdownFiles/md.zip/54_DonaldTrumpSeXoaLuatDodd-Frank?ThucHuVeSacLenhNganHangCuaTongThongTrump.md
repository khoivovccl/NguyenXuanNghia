# Donald Trump Sẽ Xóa Luật Dodd-Frank? Thực Hư Về Sắc Lệnh Ngân Hàng Của Tổng Thống Trump

23/02/2017



### Nguồn:

Viet Bao: https://vietbao.com/a264445/donald-trump-se-xoa-luat-dodd-frank-thuc-hu-ve-sac-lenh-ngan-hang-cua-tong-thong-trump

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/